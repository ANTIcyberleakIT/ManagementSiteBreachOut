"""
BreachOut escaperoom: De gestolen laptop (datalek-melden-01)

Een nep-intranet van IronHold Labs. De deelnemer moet aanwijzingen uit de
mailbox, het assetregister, de incidentdossiers en de wiki combineren en
daarna het meldformulier datalek correct invullen. Alleen bij een volledig
juist formulier verschijnt de unieke flag van het team.

- De antwoorden en de flag gaan nooit naar de browser (behalve de flag bij
  een goed formulier).
- Het formulier heeft een beperkt aantal pogingen. Daarna gaat de room op
  slot; opnieuw beginnen kan via Reset op het BreachOut-platform (dat maakt
  een nieuwe container).

Alle links zijn relatief, zodat de app werkt achter de webserver-proxy op
/room/<token>/.

Taal: Engels (standaard) of Nederlands. De room volgt de taalkeuze van het
BreachOut-platform (zelfde adres, dus dezelfde browserinstelling) via het
cookie room_lang. Inhoud en regels zijn in beide talen identiek.
"""
import fcntl
import json
import re
from pathlib import Path

import time

from flask import Flask, abort, jsonify, render_template, request

BASE = Path("/opt/intranet")
DATA_FILE = BASE / "data.json"
FLAG_FILE = BASE / "flag.txt"
STATE_DIR = BASE / "state"
STATE_FILE = STATE_DIR / "pogingen.json"
NOTES_FILE = STATE_DIR / "kladblok.json"     # gedeeld kladblok (hele team, zelfde room)
CONCEPT_FILE = STATE_DIR / "concept.json"    # gedeeld concept van het meldformulier
FORM_FIELDS = ("incident", "asset", "melden", "instantie", "deadline", "personen", "informeren")
NOTES_MAX = 20000

app = Flask(__name__)

LANGS = ("en", "nl")

# Vaste teksten van de pagina's. Inhoud (mails, wiki, ...) staat in data.json.
UI = {
    "en": {
        "alarm": "Incident open: theft of Sales laptop · report form not yet submitted",
        "nav_mail": "Mail", "nav_assets": "Asset register", "nav_dossiers": "Incident files",
        "nav_wiki": "Wiki", "nav_melden": "Report form",
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your clues here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "inbox": "Inbox", "back_inbox": "Inbox", "from": "From", "to": "To", "date": "Date",
        "assets_title": "IT asset register", "assets_ph": "Search by employee name or asset number", "search": "Search",
        "assets_help": "Enter a search term. The register shows all devices that belong to an employee.",
        "assets_none": "No devices found for", "assets_found": "device(s) found.",
        "a_number": "Asset number", "a_type": "Type", "a_user": "User", "a_status": "Status",
        "a_encrypted": "Encrypted", "a_remark": "Remark",
        "dossiers_title": "Incident files", "dossiers_ph": "Incident number, e.g. INC-2026-0000", "dossiers_open": "Open file",
        "dossiers_help": "Files can only be opened with the correct incident number.",
        "dossiers_none": "No file found with number", "d_reporter": "Reporter", "d_happened": "Happened on",
        "d_reported": "Reported on", "d_files": "Files that were on the device", "d_backup": "(according to the last backup)",
        "d_file": "File", "d_data": "Data", "d_people": "Number of people",
        "wiki_pick": "Choose an article on the left.",
        "form_title": "Data breach report form",
        "form_autosave": "This form is saved automatically and shared with your team.",
        "form_saving": "Saving...", "form_saved": "Saved and shared with your team.",
        "form_changes": "Changes...", "form_save_failed": "Saving failed, please try again.",
        "ok_title": "Report submitted correctly!",
        "ok_text": "You reported the breach in time and completely to the Autoriteit Persoonsgegevens, and the customers are being informed. Enter this code on the BreachOut platform:",
        "lock_title": "Form blocked",
        "lock_text": "You have used all {n} attempts. This room is locked. Want to try again? Use <b>Reset</b> on the BreachOut platform.",
        "wrong": "Report rejected: <b>{goed} of {totaal}</b> answers are correct. You have <b>{over}</b> attempt(s) left.",
        "warn": "Note: you have {over} of {max} attempts left. Check everything before you submit.",
        "q1": "1. Incident number", "q2": "2. Asset number of the stolen device",
        "q3": "3. Must this data breach be reported to the supervisory authority?",
        "q4": "4. To which authority is the data breach reported?",
        "q5": "5. Latest date and time of the report",
        "q6": "6. Number of people whose data was on the device",
        "q7": "7. Must the affected people be informed themselves as well?",
        "choose": "-- choose --", "yes": "Yes", "no": "No", "submit": "Submit report",
    },
    "nl": {
        "alarm": "Incident open: diefstal laptop Sales · meldformulier nog niet verstuurd",
        "nav_mail": "Mail", "nav_assets": "Assetregister", "nav_dossiers": "Incidentdossiers",
        "nav_wiki": "Wiki", "nav_melden": "Meldformulier",
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je aanwijzingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "inbox": "Postvak IN", "back_inbox": "Postvak IN", "from": "Van", "to": "Aan", "date": "Datum",
        "assets_title": "IT-assetregister", "assets_ph": "Zoek op naam medewerker of assetnummer", "search": "Zoeken",
        "assets_help": "Voer een zoekterm in. Het register toont alle apparaten die bij een medewerker horen.",
        "assets_none": "Geen apparaten gevonden voor", "assets_found": "apparaat/apparaten gevonden.",
        "a_number": "Assetnummer", "a_type": "Type", "a_user": "Gebruiker", "a_status": "Status",
        "a_encrypted": "Versleuteld", "a_remark": "Opmerking",
        "dossiers_title": "Incidentdossiers", "dossiers_ph": "Incidentnummer, bijv. INC-2026-0000", "dossiers_open": "Dossier openen",
        "dossiers_help": "Dossiers zijn alleen te openen met het juiste incidentnummer.",
        "dossiers_none": "Geen dossier gevonden met nummer", "d_reporter": "Melder", "d_happened": "Gebeurd op",
        "d_reported": "Gemeld op", "d_files": "Bestanden die op het apparaat stonden", "d_backup": "(volgens de laatste back-up)",
        "d_file": "Bestand", "d_data": "Gegevens", "d_people": "Aantal personen",
        "wiki_pick": "Kies links een artikel.",
        "form_title": "Meldformulier datalek",
        "form_autosave": "Dit formulier wordt automatisch opgeslagen en is gedeeld met je team.",
        "form_saving": "Opslaan...", "form_saved": "Opgeslagen en gedeeld met je team.",
        "form_changes": "Wijzigingen...", "form_save_failed": "Opslaan mislukt, probeer het opnieuw.",
        "ok_title": "Melding correct verstuurd!",
        "ok_text": "Je hebt het lek op tijd en volledig gemeld bij de Autoriteit Persoonsgegevens, en de klanten worden ingelicht. Vul deze code in op het BreachOut-platform:",
        "lock_title": "Formulier geblokkeerd",
        "lock_text": "Je hebt alle {n} pogingen gebruikt. Deze room is op slot. Wil je het opnieuw proberen? Gebruik <b>Reset</b> op het BreachOut-platform.",
        "wrong": "Melding afgekeurd: <b>{goed} van de {totaal}</b> antwoorden zijn goed. Je hebt nog <b>{over}</b> poging(en).",
        "warn": "Let op: je hebt {over} van de {max} pogingen over. Controleer alles voordat je verstuurt.",
        "q1": "1. Incidentnummer", "q2": "2. Assetnummer van het gestolen apparaat",
        "q3": "3. Moet dit datalek gemeld worden bij de toezichthouder?",
        "q4": "4. Bij welke instantie wordt het datalek gemeld?",
        "q5": "5. Uiterlijke datum en tijd van de melding",
        "q6": "6. Aantal personen van wie gegevens op het apparaat stonden",
        "q7": "7. Moeten de getroffen personen zelf ook geïnformeerd worden?",
        "choose": "-- kies --", "yes": "Ja", "no": "Nee", "submit": "Melding versturen",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def tr(obj, lang):
    """Vertaalbare teksten ({en: .., nl: ..}) omzetten naar de gekozen taal."""
    if isinstance(obj, dict):
        if obj and set(obj) <= set(LANGS):
            return obj.get(lang) or obj.get("en") or obj.get("nl") or ""
        return {k: tr(v, lang) for k, v in obj.items()}
    if isinstance(obj, list):
        return [tr(v, lang) for v in obj]
    return obj


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return tr(json.load(f), get_lang())


def norm(text):
    """Hoofdletters, spaties en streepjesvarianten gelijk trekken."""
    text = (text or "").strip().upper()
    text = re.sub(r"[\s‐-―]+", "-", text)
    return text


# ------------------------------------------------------------- pogingen
def read_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return {"pogingen": 0, "opgelost": False}


def update_state(fn):
    """Lees-wijzig-schrijf met een bestandslock (gunicorn draait 2 workers)."""
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE.with_suffix(".lock"), "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state = read_state()
        fn(state)
        STATE_FILE.write_text(json.dumps(state), encoding="utf-8")
        return state


# ------------------------------------------------ gedeelde opslag (team)
def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    """Veilig wegschrijven: eerst naar een tijdelijk bestand, dan hernoemen."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


def read_concept():
    return read_json(CONCEPT_FILE, {"velden": {}, "versie": 0})


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.route("/api/concept", methods=["GET", "PUT"])
def api_concept():
    if request.method == "PUT":
        nieuw = (request.get_json(silent=True) or {}).get("velden", {})
        concept = read_concept()
        for k in FORM_FIELDS:            # alleen bekende velden, kort gehouden
            if k in nieuw:
                concept["velden"][k] = str(nieuw[k])[:100]
        concept["versie"] = time.time()
        write_json(CONCEPT_FILE, concept)
    return jsonify(read_concept())


@app.context_processor
def common():
    data = load()
    state = read_state()
    lang = get_lang()
    return {
        "lang": lang, "t": UI[lang],
        # relatief pad naar de hoofdmap, voor menu-links op diepere pagina's
        "root": "../" * max(0, request.path.count("/") - 1),
        "speler": data["speler"],
        "max_pogingen": data["max_pogingen"],
        "pogingen_over": max(0, data["max_pogingen"] - state["pogingen"]),
    }


# ------------------------------------------------------------- pagina's
@app.route("/")
def inbox():
    return render_template("inbox.html", emails=load()["emails"], actief="mail")


@app.route("/mail/<int:mail_id>")
def mail(mail_id):
    for m in load()["emails"]:
        if m["id"] == mail_id:
            return render_template("mail.html", mail=m, actief="mail")
    abort(404)


@app.route("/assets")
def assets():
    q = (request.args.get("q") or "").strip()
    resultaten = None
    if q:
        ql = q.lower()
        resultaten = [a for a in load()["assets"]
                      if ql in a["gebruiker"].lower() or ql in a["nummer"].lower()]
    return render_template("assets.html", q=q, resultaten=resultaten, actief="assets")


@app.route("/dossiers")
def dossiers():
    nummer = request.args.get("nummer")
    dossier = None
    if nummer is not None:
        for d in load()["dossiers"]:
            if norm(d["nummer"]) == norm(nummer):
                dossier = d
                break
    return render_template("dossiers.html", nummer=nummer, dossier=dossier, actief="dossiers")


@app.route("/wiki")
def wiki():
    return render_template("wiki.html", artikelen=load()["wiki"], artikel=None, actief="wiki")


@app.route("/wiki/<slug>")
def wiki_artikel(slug):
    artikelen = load()["wiki"]
    for a in artikelen:
        if a["slug"] == slug:
            return render_template("wiki.html", artikelen=artikelen, artikel=a, actief="wiki")
    abort(404)


@app.route("/melden", methods=["GET", "POST"])
def melden():
    data = load()
    state = read_state()
    ctx = {"actief": "melden", "instanties": data["instanties"], "deadlines": data["deadlines"]}

    if state["opgelost"]:
        return render_template("melden.html", status="opgelost",
                               flag=FLAG_FILE.read_text(encoding="utf-8").strip(), **ctx)
    if state["pogingen"] >= data["max_pogingen"]:
        return render_template("melden.html", status="slot", **ctx)
    if request.method == "GET":
        return render_template("melden.html", status="leeg", invoer=read_concept()["velden"], **ctx)

    f = request.form
    a = data["antwoorden"]
    # wat verstuurd is, is ook het nieuwe gedeelde concept
    concept = read_concept()
    concept["velden"].update({k: f.get(k, "")[:100] for k in FORM_FIELDS})
    concept["versie"] = time.time()
    write_json(CONCEPT_FILE, concept)
    try:
        personen = int(re.sub(r"[.\s]", "", f.get("personen", "")))
    except ValueError:
        personen = -1
    checks = [
        norm(f.get("incident")) == norm(a["incident"]),
        norm(f.get("asset")) == norm(a["asset"]),
        f.get("melden") == a["melden"],
        f.get("instantie") == a["instantie"],
        f.get("deadline") == a["deadline"],
        personen == a["personen"],
        f.get("informeren") == a["informeren"],
    ]
    goed = sum(checks)
    alles_goed = goed == len(checks)

    def bij(s):
        s["pogingen"] += 1
        if alles_goed:
            s["opgelost"] = True
    state = update_state(bij)

    if alles_goed:
        return render_template("melden.html", status="opgelost",
                               flag=FLAG_FILE.read_text(encoding="utf-8").strip(), **ctx)
    if state["pogingen"] >= data["max_pogingen"]:
        return render_template("melden.html", status="slot", **ctx)
    # Bewust alleen het aantal goede antwoorden, niet welke.
    return render_template("melden.html", status="fout", goed=goed, totaal=len(checks),
                           invoer=f, over=data["max_pogingen"] - state["pogingen"], **ctx)


@app.route("/api/flag")
def api_flag():
    """Door het BreachOut-platform opgehaald (spelleider) om de unieke flag van
    deze draaiende room te kunnen tonen. Alleen de webserver kan dit IP bereiken."""
    try:
        return jsonify(flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
