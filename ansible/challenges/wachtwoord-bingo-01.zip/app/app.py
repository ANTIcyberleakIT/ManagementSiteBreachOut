"""
BreachOut escaperoom: Wachtwoord-bingo (wachtwoord-bingo-01)

Een makkelijke, educatieve room over wachtwoordsterkte. De speler:
  1. klikt wachtwoorden aan en ziet een geschatte kraaktijd (ter illustratie);
  2. vinkt aan welke wachtwoorden binnen seconden te kraken zijn;
  3. maakt zelf een sterk wachtwoord dat aan de regels voldoet.
Alleen als beide stappen kloppen, verschijnt de unieke flag van het team.

De "kraaktijd" is een vaste educatieve schatting uit data.json, geen echt
kraakprogramma. Er wordt niets aangevallen; het doel is leren herkennen.

Taal: Engels (standaard) of Nederlands, volgt het BreachOut-platform via het
cookie room_lang. Inhoud en regels zijn in beide talen identiek.

Alle links zijn relatief, zodat de app werkt achter de webserver-proxy op
/room/<token>/.
"""
import fcntl
import json
import re
from pathlib import Path

import time

from flask import Flask, jsonify, render_template, request

BASE = Path("/opt/pwbingo")
DATA_FILE = BASE / "data.json"
FLAG_FILE = BASE / "flag.txt"
STATE_DIR = BASE / "state"
STATE_FILE = STATE_DIR / "pogingen.json"
NOTES_FILE = STATE_DIR / "kladblok.json"     # gedeeld kladblok (hele team)
CONCEPT_FILE = STATE_DIR / "concept.json"    # gedeelde antwoorden (hele team)
NOTES_MAX = 20000

app = Flask(__name__)

LANGS = ("en", "nl")

UI = {
    "en": {
        "title": "The Weakest Password",
        "nav_game": "The game", "nav_tips": "Tips",
        "notes": "Notepad", "notes_shared": "shared",
        "notes_ph": "Write down your answers here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "intro_title": "Welcome to the security training!",
        "intro": "Not every password is equally safe. A strong password takes a computer a very long time to guess. A weak one is cracked in seconds. Learn to tell the difference and you escape this room.",
        "step1_title": "Step 1 - Which passwords are cracked within seconds?",
        "step1_help": "Click a password to see roughly how long it takes to crack. Then tick the ones a computer guesses within seconds.",
        "crack_time": "Estimated crack time", "why": "Why",
        "tick": "Crackable within seconds",
        "step2_title": "Step 2 - Now make a strong password yourself",
        "step2_help": "A good password is above all LONG. Choose one of these:",
        "rule_words": "at least {n} words with a space or - between them (a passphrase), e.g. three random words plus one",
        "rule_mix": "or at least {n} characters with an upper case, lower case, digit and symbol",
        "step2_ph": "Type your strong password",
        "autosave": "Your answers are saved automatically and shared with your team.",
        "saving": "Saving...", "saved": "Saved and shared with your team.",
        "changes": "Changes...", "save_failed": "Saving failed, please try again.",
        "submit": "Check my answers",
        "ok_title": "Escaped! Well done.",
        "ok_text": "You can tell weak passwords from strong ones, and you built a strong password yourself. Enter this code on the BreachOut platform:",
        "lock_title": "Locked",
        "lock_text": "You have used all {n} attempts. This room is locked. Want to try again? Use <b>Reset</b> on the BreachOut platform.",
        "warn": "You have {over} of {max} attempts left. Check both steps before you submit.",
        "err_step1": "Step 1 is not completely right yet: look again at which passwords are cracked within seconds.",
        "err_too_short": "Your own password is too short. Make it longer: 4 words, or at least 12 characters.",
        "err_predictable": "Your own password contains a word that is too predictable (like a season or \"welcome\"). Choose other words.",
        "err_fromlist": "That is one of the passwords from the list. Make up your OWN strong password instead.",
        "err_mix": "Almost! 12 characters is fine, but then use an upper case, lower case, digit and symbol. Or use 4 words instead.",
        "attempts": "{n} of {max} attempts left.",
        "key_title": "You cracked the basics!",
        "key_text": "You can tell weak passwords from strong ones, and you built a strong one yourself. Here is the key to the next room:",
        "key_go": "Enter room 2",
        "room2_title": "Room 2 - Crack the login",
        "room2_intro": "A new employee of IronHold Labs chose a very predictable password. Guess it and you escape. Use the tips if you get stuck - this shows how easily a weak password is guessed.",
        "account": "Account", "pw_label": "Password", "pw_ph": "Type the password",
        "show_tip": "Need help? Each tip costs 10 points.", "tip": "Tip",
        "tip_btn": "Show tip {i} (-10 points)", "tips_cost": "Tips used: {n} ({p} points)",
        "crack_submit": "Try password",
        "crack_wrong": "Not correct yet. Open another tip and look at the pattern.",
        "tips_title": "Tips for a strong password",
        "tips": [
            "Length beats complexity. Four random words are stronger than Welkom01!",
            "Use a different password for every website.",
            "A password manager remembers them for you.",
            "Turn on two-factor authentication (2FA) where you can.",
            "Never reuse a work password for a private account.",
        ],
    },
    "nl": {
        "title": "Het zwakste wachtwoord",
        "nav_game": "Het spel", "nav_tips": "Tips",
        "notes": "Kladblok", "notes_shared": "gedeeld",
        "notes_ph": "Schrijf hier je antwoorden op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "intro_title": "Welkom bij de security-training!",
        "intro": "Niet elk wachtwoord is even veilig. Over een sterk wachtwoord doet een computer heel lang om het te raden. Een zwak wachtwoord is in seconden gekraakt. Leer het verschil herkennen en je ontsnapt uit deze room.",
        "step1_title": "Stap 1 - Welke wachtwoorden zijn binnen seconden te kraken?",
        "step1_help": "Klik op een wachtwoord om te zien hoe lang kraken ongeveer duurt. Vink daarna de wachtwoorden aan die een computer binnen seconden raadt.",
        "crack_time": "Geschatte kraaktijd", "why": "Waarom",
        "tick": "Binnen seconden te kraken",
        "step2_title": "Stap 2 - Maak nu zelf een sterk wachtwoord",
        "step2_help": "Een goed wachtwoord is vooral LANG. Kies een van deze:",
        "rule_words": "minstens {n} woorden met een spatie of - ertussen (een wachtzin), bijv. drie willekeurige woorden plus een",
        "rule_mix": "of minstens {n} tekens met een hoofdletter, kleine letter, cijfer en teken",
        "step2_ph": "Typ je sterke wachtwoord",
        "autosave": "Je antwoorden worden automatisch opgeslagen en zijn gedeeld met je team.",
        "saving": "Opslaan...", "saved": "Opgeslagen en gedeeld met je team.",
        "changes": "Wijzigingen...", "save_failed": "Opslaan mislukt, probeer het opnieuw.",
        "submit": "Controleer mijn antwoorden",
        "ok_title": "Ontsnapt! Goed gedaan.",
        "ok_text": "Je ziet het verschil tussen zwakke en sterke wachtwoorden, en je hebt zelf een sterk wachtwoord gemaakt. Vul deze code in op het BreachOut-platform:",
        "lock_title": "Op slot",
        "lock_text": "Je hebt alle {n} pogingen gebruikt. Deze room is op slot. Wil je het opnieuw proberen? Gebruik <b>Reset</b> op het BreachOut-platform.",
        "warn": "Je hebt nog {over} van de {max} pogingen. Controleer beide stappen voordat je verstuurt.",
        "err_step1": "Stap 1 klopt nog niet helemaal: kijk nog eens welke wachtwoorden binnen seconden te kraken zijn.",
        "err_too_short": "Je eigen wachtwoord is te kort. Maak het langer: 4 woorden, of minstens 12 tekens.",
        "err_predictable": "Je eigen wachtwoord bevat een woord dat te voorspelbaar is (zoals een seizoen of \"welkom\"). Kies andere woorden.",
        "err_fromlist": "Dat is een van de wachtwoorden uit de lijst. Verzin juist je EIGEN sterke wachtwoord.",
        "err_mix": "Bijna! 12 tekens is prima, maar gebruik dan ook een hoofdletter, kleine letter, cijfer en teken. Of gebruik juist 4 woorden.",
        "attempts": "Nog {n} van de {max} pogingen.",
        "key_title": "Je hebt de basis gekraakt!",
        "key_text": "Je ziet het verschil tussen zwakke en sterke wachtwoorden, en je hebt er zelf een sterk gemaakt. Hier is de sleutel naar de volgende kamer:",
        "key_go": "Ga naar kamer 2",
        "room2_title": "Kamer 2 - Kraak de login",
        "room2_intro": "Een nieuwe medewerker van IronHold Labs koos een heel voorspelbaar wachtwoord. Raad het en je ontsnapt. Gebruik de tips als je vastloopt - zo zie je hoe makkelijk een zwak wachtwoord te raden is.",
        "account": "Account", "pw_label": "Wachtwoord", "pw_ph": "Typ het wachtwoord",
        "show_tip": "Hulp nodig? Elke tip kost 10 punten.", "tip": "Tip",
        "tip_btn": "Toon tip {i} (-10 punten)", "tips_cost": "Tips gebruikt: {n} ({p} punten)",
        "crack_submit": "Probeer wachtwoord",
        "crack_wrong": "Nog niet goed. Klap nog een tip open en kijk naar het patroon.",
        "tips_title": "Tips voor een sterk wachtwoord",
        "tips": [
            "Lengte wint van ingewikkeldheid. Vier willekeurige woorden zijn sterker dan Welkom01!",
            "Gebruik voor elke website een ander wachtwoord.",
            "Een wachtwoordmanager onthoudt ze voor je.",
            "Zet tweestapsverificatie (2FA) aan waar het kan.",
            "Gebruik nooit een werkwachtwoord opnieuw voor een privé-account.",
        ],
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def tr(obj, lang):
    if isinstance(obj, dict):
        if obj and set(obj) <= set(LANGS):
            return obj.get(lang) or obj.get("en") or obj.get("nl") or ""
        return {k: tr(v, lang) for k, v in obj.items()}
    if isinstance(obj, list):
        return [tr(v, lang) for v in obj]
    return obj


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------- pogingen
def read_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return {"pogingen": 0, "opgelost": False, "stage": 1, "tips_open": []}


def update_state(fn):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "pogingen.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state = read_state()
        fn(state)
        STATE_FILE.write_text(json.dumps(state), encoding="utf-8")
        return state


# ------------------------------------------------ gedeelde opslag (team)
def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


def read_concept():
    return read_json(CONCEPT_FILE, {"zwak": [], "eigen": "", "versie": 0})


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.route("/api/concept", methods=["GET", "PUT"])
def api_concept():
    if request.method == "PUT":
        body = request.get_json(silent=True) or {}
        concept = read_concept()
        if "zwak" in body and isinstance(body["zwak"], list):
            geldig = {w["id"] for w in load()["wachtwoorden"]}
            concept["zwak"] = [int(i) for i in body["zwak"] if int(i) in geldig][:20]
        if "eigen" in body:
            concept["eigen"] = str(body["eigen"])[:100]
        concept["versie"] = time.time()
        write_json(CONCEPT_FILE, concept)
    return jsonify(read_concept())


@app.context_processor
def common():
    lang = get_lang()
    return {"lang": lang, "t": UI[lang]}


# ------------------------------------------------ controle van het eigen wachtwoord
def norm_pw(s):
    """Hoofdletters, spaties en streepjes negeren bij het vergelijken."""
    return re.sub(r"[\s-]+", "", (s or "").strip().lower())


def sterk_genoeg(pw, regels, verboden, lijst_pws=()):
    pw = (pw or "").strip()
    woorden = [w for w in re.split(r"[\s-]+", pw) if w]
    laag = pw.lower()
    # een wachtwoord uit de voorbeeldlijst mag niet: zelf verzinnen is de opdracht
    if norm_pw(pw) in {norm_pw(p) for p in lijst_pws}:
        return "fromlist"
    bevat_verboden = any(v in laag for v in verboden)
    # route 1: genoeg losse woorden (wachtzin)
    if len(woorden) >= regels["min_woorden"] and len(pw) >= 12:
        if bevat_verboden:
            return "predictable"
        return "ok"
    # route 2: lang genoeg met een goede mix
    if len(pw) >= regels["min_lengte_mix"]:
        mix = (re.search(r"[a-z]", pw) and re.search(r"[A-Z]", pw)
               and re.search(r"\d", pw) and re.search(r"[^A-Za-z0-9]", pw))
        if not mix:
            return "mix"
        if bevat_verboden:
            return "predictable"
        return "ok"
    return "short"


# ------------------------------------------------------------- pagina's
@app.route("/")
def spel():
    data = load()
    lang = get_lang()
    concept = read_concept()
    state = read_state()
    pws = [{"id": w["id"], "pw": w["pw"], "tijd": tr(w["tijd"], lang),
            "uitleg": tr(w["uitleg"], lang)} for w in data["wachtwoorden"]]
    if state["opgelost"]:
        status = "opgelost"
    elif state.get("stage", 1) == 2:
        status = "kamer2"
    elif state["pogingen"] >= data["max_pogingen"]:
        status = "slot"
    else:
        status = "spel"
    k2 = data["kamer2"]
    return render_template(
        "spel.html", actief="game", status=status,
        wachtwoorden=pws, regels=data["regels"], concept=concept,
        flag=(FLAG_FILE.read_text(encoding="utf-8").strip() if state["opgelost"] else None),
        max_pogingen=data["max_pogingen"], pogingen_over=max(0, data["max_pogingen"] - state["pogingen"]),
        k2_account=k2["account"], k2_tips=[tr(t, lang) for t in k2["tips"]],
        tips_open=state.get("tips_open", []),
    )


@app.route("/tips")
def tips():
    return render_template("tips.html", actief="tips")


@app.route("/controleer", methods=["POST"])
def controleer():
    data = load()
    state = read_state()
    if state["opgelost"] or state["pogingen"] >= data["max_pogingen"]:
        return jsonify(ok=False, fout="slot")

    concept = read_concept()
    gekozen = set(concept.get("zwak", []))
    juist = {w["id"] for w in data["wachtwoorden"] if w["zwak"]}
    stap1_ok = gekozen == juist
    stap2 = sterk_genoeg(concept.get("eigen", ""), data["regels"], data["verboden_woorden"],
                         [w["pw"] for w in data["wachtwoorden"]])

    alles_goed = stap1_ok and stap2 == "ok"

    def bij(s):
        s["pogingen"] += 1
        if alles_goed:
            s["stage"] = 2          # sleutel naar kamer 2, nog niet opgelost
    state = update_state(bij)

    if alles_goed:
        return jsonify(ok=True, stage=2)
    if state["pogingen"] >= data["max_pogingen"]:
        return jsonify(ok=False, fout="slot")
    # eerst stap 1, dan het eigen wachtwoord; één reden tegelijk
    reden = "step1" if not stap1_ok else {"short": "too_short", "mix": "mix", "predictable": "predictable", "fromlist": "fromlist"}[stap2]
    return jsonify(ok=False, fout=reden, over=data["max_pogingen"] - state["pogingen"])


@app.route("/api/tip", methods=["POST"])
def api_tip():
    data = load()
    tips = data["kamer2"]["tips"]
    i = (request.get_json(silent=True) or {}).get("i")
    if not isinstance(i, int) or not (0 <= i < len(tips)):
        return jsonify(error="bad tip"), 400
    def bij(s):
        s.setdefault("tips_open", [])
        if i not in s["tips_open"]:
            s["tips_open"].append(i)
    state = update_state(bij)
    lang = get_lang()
    return jsonify(tekst=tr(tips[i], lang), tips_open=state["tips_open"], tips_used=len(state["tips_open"]))


@app.route("/api/score")
def api_score():
    """Door de webapp opgehaald bij het oplossen: aantal gebruikte tips = -10 elk."""
    return jsonify(tips_used=len(read_state().get("tips_open", [])))


@app.route("/kraak", methods=["POST"])
def kraak():
    data = load()
    state = read_state()
    if state["opgelost"]:
        return jsonify(ok=True, flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    if state.get("stage", 1) != 2:
        return jsonify(ok=False, fout="volgorde")
    poging = (request.get_json(silent=True) or {}).get("wachtwoord", "")
    if norm_pw(poging) == norm_pw(data["kamer2"]["wachtwoord"]):
        update_state(lambda s: s.update(opgelost=True))
        return jsonify(ok=True, flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    return jsonify(ok=False, fout="wrong")


@app.route("/api/flag")
def api_flag():
    """Door het BreachOut-platform opgehaald (spelleider) om de unieke flag van
    deze draaiende room te kunnen tonen. Alleen de webserver kan dit IP bereiken."""
    try:
        return jsonify(flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
