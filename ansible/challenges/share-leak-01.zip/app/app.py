"""
BreachOut escaperoom: The Wrong Share Link (share-leak-01)

Difficult onderzoekschallenge. Een map werd per ongeluk publiek gedeeld. De speler
moet met echt forensisch werk bewijzen dat een buitenstaander data exfiltreerde en
het bewijs-kenmerk uit het gestolen bestand halen:

  1. Teamchat -> context + "check de audit-log".
  2. Audit-log (ruis): vind de afwijkende EXTERNE toegang (let op een legitieme
     externe afleider). De dader downloadt salarissen_2026.xlsx via de publieke link.
  3. Bestandsforensiek: salarissen_2026.xlsx is een ZIP met een VERBORGEN
     (veryHidden) werkblad dat een base64-string bevat.
  4. Decodeer base64 -> de flag.

De flag is AFGELEID/VAST (flag{...}) en wordt bij registratie ingevuld.
Taal: EN (standaard) of NL via cookie room_lang. Alle pagina's op één niveau.
"""
import json
from pathlib import Path

import time
import fcntl
from flask import Flask, Response, abort, jsonify, render_template, request, send_file

BASE = Path("/opt/sharecase")
STATE_DIR = BASE / "state"
NOTES_FILE = STATE_DIR / "kladblok.json"
NOTES_MAX = 20000
DATA_FILE = BASE / "data.json"
XLSX_FILE = BASE / "static" / "salarissen_2026.xlsx"

app = Flask(__name__)
LANGS = ("en", "nl")

UI = {
    "en": {
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "brand": "IronHold Drive", "case": "Incident review: over-shared folder",
        "nav_chat": "Team chat", "nav_log": "Audit log", "nav_share": "Shared files",
        "chat_title": "Team chat", "chat_hint": "Recovered conversation from the finance team channel.",
        "log_title": "Drive audit log", "log_hint": "Access events exported from the shared drive. Most of this is normal internal activity - find the access that should not be there. Tip: search for a folder name, an action (download) or an IP.",
        "search_ph": "Filter the log... (e.g. Financieel, download, or an IP)", "download_log": "Download log (.txt)",
        "c_time": "Time", "c_actor": "Actor", "c_ip": "IP", "c_action": "Action", "c_item": "Item", "c_via": "Via",
        "lines_total": "{n} events", "lines_match": "{n} of {t} events match \"{q}\"",
        "share_title": "Shared files & folders", "share_hint": "Everything shared from this drive. Check the sharing settings.",
        "col_name": "Name", "col_shared": "Shared with", "col_perm": "Access", "open": "Open",
        "perm_public": "Anyone with the link", "perm_restricted": "Specific people",
        "folder": "Folder", "empty": "This folder has no files you can see.",
        "noaccess_title": "No access", "noaccess": "This folder is shared only with specific people.",
        "back_share": "Back", "download": "Download",
        "preview_none_title": "Preview not available", "preview_none": "No preview for this file type. Tip: download it and inspect it properly - office files are more than they seem.",
        "notfound": "Not found.", "viewer": "File preview",
    },
    "nl": {
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "brand": "IronHold Drive", "case": "Incidentonderzoek: te ruim gedeelde map",
        "nav_chat": "Teamchat", "nav_log": "Audit-log", "nav_share": "Gedeelde bestanden",
        "chat_title": "Teamchat", "chat_hint": "Teruggehaald gesprek uit het finance-kanaal.",
        "log_title": "Drive audit-log", "log_hint": "Toegang-events geexporteerd uit de gedeelde drive. Het meeste is normale interne activiteit - vind de toegang die er niet hoort te zijn. Tip: zoek op een mapnaam, een actie (download) of een IP.",
        "search_ph": "Filter de log... (bijv. Financieel, download, of een IP)", "download_log": "Log downloaden (.txt)",
        "c_time": "Tijd", "c_actor": "Actor", "c_ip": "IP", "c_action": "Actie", "c_item": "Item", "c_via": "Via",
        "lines_total": "{n} events", "lines_match": "{n} van {t} events bevatten \"{q}\"",
        "share_title": "Gedeelde bestanden & mappen", "share_hint": "Alles wat vanaf deze drive is gedeeld. Bekijk de deel-instellingen.",
        "col_name": "Naam", "col_shared": "Gedeeld met", "col_perm": "Toegang", "open": "Openen",
        "perm_public": "Iedereen met de link", "perm_restricted": "Specifieke personen",
        "folder": "Map", "empty": "Deze map heeft geen bestanden die je kunt zien.",
        "noaccess_title": "Geen toegang", "noaccess": "Deze map is alleen met specifieke personen gedeeld.",
        "back_share": "Terug", "download": "Downloaden",
        "preview_none_title": "Voorbeeld niet beschikbaar", "preview_none": "Geen voorbeeld voor dit bestandstype. Tip: download het en inspecteer het goed - office-bestanden zijn meer dan ze lijken.",
        "notfound": "Niet gevonden.", "viewer": "Bestandsvoorbeeld",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def tr(obj, lang):
    if isinstance(obj, dict):
        if obj and set(obj) <= set(LANGS):
            return obj.get(lang) or obj.get("en") or ""
        return {k: tr(v, lang) for k, v in obj.items()}
    if isinstance(obj, list):
        return [tr(v, lang) for v in obj]
    return obj


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------- audit-log deterministisch opbouwen
def _sortkey(datum, tijd):
    d, m, y = datum.split("-")
    return (y, m, d, tijd)


def build_log(data):
    a = data["audit"]
    seed = [20260211]

    def rnd(n):
        seed[0] = (seed[0] * 1103515245 + 12345) & 0x7fffffff
        return seed[0] % n

    rows = []
    acties = ["view", "view", "view", "edit", "download", "view", "share-view"]
    # interne ruis: ~22 events per dag, werktijden
    for datum in a["datums"]:
        for _ in range(22):
            u = a["intern"][rnd(len(a["intern"]))]
            item = a["items_intern"][rnd(len(a["items_intern"]))]
            act = acties[rnd(len(acties))]
            hh = 8 + rnd(10)       # 08-17
            mm = rnd(60); ss = rnd(60)
            rows.append({"datum": datum, "tijd": f"{hh:02d}:{mm:02d}:{ss:02d}",
                         "actor": u["actor"], "ip": u["ip"], "action": act,
                         "item": item, "via": "intern"})
    # legitieme externe afleider: bureau opent Marketing via link (overdag)
    d = a["decoy_extern"]
    for i, item in enumerate(d["items"]):
        hh = 11 + i; mm = 20 + rnd(30)
        rows.append({"datum": a["datums"][0], "tijd": f"{hh:02d}:{mm:02d}:{rnd(60):02d}",
                     "actor": d["actor"], "ip": d["ip"], "action": "view",
                     "item": item, "via": d["via"]})
    # de dader: externe gast via publieke Financieel-link, laat op de avond
    at = a["aanvaller"]
    for ev in at["acties"]:
        rows.append({"datum": at["datum"], "tijd": ev["tijd"], "actor": at["actor"],
                     "ip": at["ip"], "action": ev["action"], "item": ev["item"], "via": at["via"]})

    rows.sort(key=lambda r: _sortkey(r["datum"], r["tijd"]))
    return rows



def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    """Gedeeld kladblok voor het team (server-side, zodat teamgenoten het ook zien)."""
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.context_processor
def common():
    return {"lang": get_lang(), "t": UI[get_lang()]}


@app.route("/")
def chat():
    data = load()
    lang = get_lang()
    berichten = [{"van": b["van"], "tijd": b["tijd"], "tekst": tr(b["tekst"], lang)}
                 for b in data["chat"]["berichten"]]
    return render_template("chat.html", actief="chat",
                           kanaal=data["chat"]["kanaal"], berichten=berichten)


@app.route("/log")
def log():
    rows = build_log(load())
    return render_template("log.html", actief="log", rows=rows, totaal=len(rows))


@app.route("/audit.txt")
def audit_txt():
    rows = build_log(load())
    lines = ["{datum} {tijd}  {actor:38}  {ip:16}  {action:12}  {via:20}  {item}".format(**r) for r in rows]
    return Response("\n".join(lines) + "\n", mimetype="text/plain",
                    headers={"Content-Disposition": "attachment; filename=audit.txt"})


@app.route("/share")
def share():
    data = load()
    return render_template("share.html", actief="share", shares=data["shares"])


@app.route("/folder")
def folder():
    data = load()
    naam = request.args.get("name", "")
    s = next((x for x in data["shares"] if x["naam"] == naam), None)
    if not s:
        return render_template("folder.html", actief="share", notfound=True, naam=naam), 404
    if s["rechten"] != "public":
        return render_template("folder.html", actief="share", noaccess=True, naam=naam)
    return render_template("folder.html", actief="share", naam=naam, bestanden=s["bestanden"])


@app.route("/view")
def view():
    data = load()
    f = request.args.get("file", "")
    if f == "notities.txt":
        return render_template("notes.html", actief="share",
                               naam=f, inhoud=tr(data["notities"], get_lang()))
    return render_template("notes.html", actief="share", naam=f, geen=True)


@app.route("/download/salarissen_2026.xlsx")
def download_xlsx():
    if not XLSX_FILE.exists():
        abort(404)
    return send_file(str(XLSX_FILE), as_attachment=True,
                     download_name="salarissen_2026.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/api/flag")
def api_flag():
    try:
        return jsonify(flag=load()["flag"])
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
