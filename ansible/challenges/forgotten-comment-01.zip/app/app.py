"""
BreachOut escaperoom: The Forgotten Comment (forgotten-comment-01)

Intermediate web-recon challenge. De speler bekijkt een gewone bedrijfssite
van IronHold Labs en moet via verkenning binnenkomen:
  - robots.txt verraadt een verborgen /admin-pagina (met wat afleiders);
  - in de BRON van de vacaturepagina (/careers) staat een vergeten HTML-
    commentaar met een testlogin (test / Test123);
  - met die login op /admin verschijnt de unieke flag van het team.

Er wordt niets echt aangevallen; de speler oefent met paginabron bekijken
(F12 / Ctrl+U) en robots.txt lezen.

Taal: Engels (standaard) of Nederlands, volgt het platform via cookie room_lang.
Alle links zijn relatief, zodat de app werkt achter de webserver-proxy op
/room/<token>/.
"""
import fcntl
import json
from pathlib import Path

import time
from flask import Flask, Response, jsonify, redirect, render_template, request

BASE = Path("/opt/webclue")
DATA_FILE = BASE / "data.json"
FLAG_FILE = BASE / "flag.txt"
STATE_DIR = BASE / "state"
STATE_FILE = STATE_DIR / "pogingen.json"
NOTES_FILE = STATE_DIR / "kladblok.json"
NOTES_MAX = 20000

app = Flask(__name__)
LANGS = ("en", "nl")

UI = {
    "en": {
        "nav_home": "Home", "nav_products": "Products", "nav_careers": "Careers",
        "tagline": "Industrial security hardware, built to last.",
        "home_lead": "IronHold Labs designs tamper-proof locks, secure enclosures and "
                     "access controllers for critical infrastructure.",
        "home_more": "Trusted by data centers, utilities and government sites across Europe.",
        "products_title": "Our products",
        "p1": "IronHold Vault Door X9", "p1d": "Blast-rated door with dual-factor access control.",
        "p2": "SecureRack Enclosure", "p2d": "Lockable 42U server rack with intrusion sensors.",
        "p3": "AccessPoint Controller", "p3d": "Central badge and PIN controller for up to 128 doors.",
        "careers_title": "Working at IronHold Labs",
        "careers_lead": "We are hiring engineers, technicians and security specialists.",
        "careers_body": "Send your CV to jobs@ironholdlabs.nl. Our intranet and admin tools "
                        "are for staff only.",
        "foot": "IronHold Labs BV — Gordon House, Dublin. Internal systems are monitored.",
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "admin_title": "Staff login",
        "admin_sub": "Restricted area. Authorized personnel only.",
        "u": "Username", "p": "Password", "login": "Log in",
        "wrong": "Invalid username or password. {n} attempt(s) left.",
        "locked_title": "Account locked",
        "locked_text": "Too many failed logins. This panel is locked and the challenge is "
                       "marked as failed. Ask the game master for another try.",
        "ok_title": "Admin panel", "ok_hi": "Welcome back, test.",
        "ok_text": "You found the hidden panel and the forgotten test login. Enter this code "
                   "on the BreachOut platform:",
        "backup_title": "Directory listing denied",
        "backup_text": "You don't have permission to access this resource on this server.",
    },
    "nl": {
        "nav_home": "Home", "nav_products": "Producten", "nav_careers": "Vacatures",
        "tagline": "Industriële beveiligingshardware, gemaakt om te blijven.",
        "home_lead": "IronHold Labs ontwerpt sabotagebestendige sloten, beveiligde behuizingen "
                     "en toegangscontrollers voor kritieke infrastructuur.",
        "home_more": "Vertrouwd door datacenters, nutsbedrijven en overheden in heel Europa.",
        "products_title": "Onze producten",
        "p1": "IronHold Vault Door X9", "p1d": "Explosiebestendige deur met tweefactor-toegang.",
        "p2": "SecureRack behuizing", "p2d": "Afsluitbaar 42U-serverrack met inbraaksensoren.",
        "p3": "AccessPoint Controller", "p3d": "Centrale badge- en pincontroller voor tot 128 deuren.",
        "careers_title": "Werken bij IronHold Labs",
        "careers_lead": "We zoeken engineers, technici en beveiligingsspecialisten.",
        "careers_body": "Stuur je cv naar jobs@ironholdlabs.nl. Ons intranet en de admin-tools "
                        "zijn alleen voor medewerkers.",
        "foot": "IronHold Labs BV — Gordon House, Dublin. Interne systemen worden gemonitord.",
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "admin_title": "Medewerkers-login",
        "admin_sub": "Afgeschermd gebied. Alleen voor bevoegd personeel.",
        "u": "Gebruikersnaam", "p": "Wachtwoord", "login": "Inloggen",
        "wrong": "Ongeldige gebruikersnaam of wachtwoord. Nog {n} poging(en).",
        "locked_title": "Account geblokkeerd",
        "locked_text": "Te veel mislukte logins. Dit paneel is op slot en de challenge is "
                       "gefaald. Vraag de spelleider om een nieuwe poging.",
        "ok_title": "Adminpaneel", "ok_hi": "Welkom terug, test.",
        "ok_text": "Je vond het verborgen paneel en de vergeten testlogin. Vul deze code in "
                   "op het BreachOut-platform:",
        "backup_title": "Toegang tot map geweigerd",
        "backup_text": "Je hebt geen toestemming om deze bron op deze server te benaderen.",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------- state
def read_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return {"pogingen": 0, "opgelost": False}


def update_state(fn):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "pogingen.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state = read_state()
        fn(state)
        STATE_FILE.write_text(json.dumps(state), encoding="utf-8")
        return state



def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    """Gedeeld kladblok voor het team (server-side, zodat teamgenoten het ook zien)."""
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.context_processor
def common():
    lang = get_lang()
    data = load()
    return {"lang": lang, "t": UI[lang], "bedrijf": data["bedrijf"]}


# ------------------------------------------------------------- publieke site
@app.route("/")
def home():
    return render_template("home.html", actief="home")


@app.route("/products")
def products():
    return render_template("products.html", actief="products")


@app.route("/careers")
def careers():
    # In de BRON van deze pagina staat het vergeten testlogin-commentaar.
    data = load()
    return render_template("careers.html", actief="careers",
                           testuser=data["login"]["gebruiker"],
                           testpass=data["login"]["wachtwoord"])


@app.route("/robots.txt")
def robots():
    data = load()
    regels = ["User-agent: *"] + [f"Disallow: {p}" for p in data["robots"]]
    return Response("\n".join(regels) + "\n", mimetype="text/plain")


# Een paar afleider-paden uit robots.txt die nergens heen leiden.
@app.route("/backup")
@app.route("/backup/")
@app.route("/old-site")
@app.route("/old-site/")
@app.route("/wp-admin")
@app.route("/wp-admin/")
def decoy():
    return render_template("backup.html"), 403


# ------------------------------------------------------------- verborgen /admin
@app.route("/admin", methods=["GET", "POST"])
@app.route("/admin/", methods=["GET", "POST"])
def admin():
    data = load()
    state = read_state()
    maxp = data["max_pogingen"]

    if state["opgelost"]:
        return render_template("success.html",
                               flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    if state["pogingen"] >= maxp:
        return render_template("admin.html", status="slot")

    if request.method == "POST":
        u = (request.form.get("user") or "").strip()
        p = request.form.get("pass") or ""
        goed = (u.lower() == data["login"]["gebruiker"].lower()
                and p == data["login"]["wachtwoord"])

        def bij(s):
            if goed:
                s["opgelost"] = True
            else:
                s["pogingen"] += 1
        state = update_state(bij)

        if goed:
            return render_template("success.html",
                                   flag=FLAG_FILE.read_text(encoding="utf-8").strip())
        if state["pogingen"] >= maxp:
            return render_template("admin.html", status="slot")
        return render_template("admin.html", status="fout",
                               over=maxp - state["pogingen"])

    return render_template("admin.html", status="leeg")


@app.route("/api/flag")
def api_flag():
    """Door het BreachOut-platform opgehaald (spelleider) om de unieke flag van
    deze draaiende room te kunnen tonen."""
    try:
        return jsonify(flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
