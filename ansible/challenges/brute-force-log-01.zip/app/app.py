"""
BreachOut escaperoom: The Breach in the Logs (brute-force-log-01)

Intermediate forensische challenge. De speler onderzoekt een nep auth.log van
de SSH-bastion van IronHold Labs:
  - een monitoring-alert legt de casus uit;
  - een doorzoekbare en downloadbare auth.log (±200 regels);
  - een onderzoeksrapport: welk IP bruteforcete, welk account is gekraakt,
    hoe laat kwam de aanvaller binnen, en wat doe je als eerste.
Alleen bij een volledig juist rapport verschijnt de unieke flag van het team.

De auth.log wordt deterministisch uit data.json opgebouwd, zodat de antwoorden
altijd bij de log passen. Er wordt niets echt aangevallen.

Taal: Engels (standaard) of Nederlands, volgt het platform via cookie room_lang.

Alle links zijn relatief, zodat de app werkt achter de webserver-proxy op
/room/<token>/.
"""
import fcntl
import json
import re
import time
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request

BASE = Path("/opt/logcase")
DATA_FILE = BASE / "data.json"
FLAG_FILE = BASE / "flag.txt"
STATE_DIR = BASE / "state"
STATE_FILE = STATE_DIR / "pogingen.json"
NOTES_FILE = STATE_DIR / "kladblok.json"
CONCEPT_FILE = STATE_DIR / "concept.json"
FORM_FIELDS = ("ip", "account", "tijd", "actie")
NOTES_MAX = 20000

app = Flask(__name__)

LANGS = ("en", "nl")

UI = {
    "en": {
        "title": "The Breach in the Logs",
        "nav_alert": "Alert", "nav_log": "auth.log", "nav_report": "Report",
        "notes": "Notepad", "notes_shared": "shared",
        "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "alert_from": "Monitoring <monitoring@ironholdlabs.nl>",
        "alert_subject": "ALERT: many failed SSH logins on {host}",
        "alert_body": (
            "The monitoring system detected an unusually high number of failed SSH logins "
            "on the bastion host {host} tonight. This looks like a brute-force attack.\n\n"
            "You are on duty. Investigate the authentication log and find out:\n"
            "  1. Which IP address kept trying to log in (the attacker)?\n"
            "  2. Which account did the attacker finally break into?\n"
            "  3. At what time did the attacker get in?\n"
            "  4. What should you do first?\n\n"
            "Open the auth.log (menu above), search through it, and fill in the Report.\n"
            "Tip: use the search box to filter lines. The notepad is at the bottom right.\n"
            "Note: the report form only accepts a few attempts."
        ),
        "log_title": "Authentication log  —  /var/log/auth.log",
        "log_help": "Search to filter lines (e.g. an IP address or \"Failed password\"). Line numbers are on the left.",
        "search_ph": "Search in the log...", "download": "Download auth.log",
        "lines_total": "{n} lines", "lines_match": "{n} of {t} lines match \"{q}\"",
        "report_title": "Incident report",
        "report_autosave": "This report is saved automatically and shared with your team.",
        "saving": "Saving...", "saved": "Saved and shared with your team.",
        "changes": "Changes...", "save_failed": "Saving failed, please try again.",
        "q_ip": "1. Attacker IP address (the one with by far the most failed logins)",
        "q_account": "2. Which account did the attacker finally break into?",
        "q_tijd": "3. At what time did the attacker get in? (HH:MM:SS, from the 'Accepted password' line of that IP)",
        "q_actie": "4. What should you do first?",
        "ph_ip": "e.g. 10.0.0.1", "ph_account": "username", "ph_tijd": "HH:MM:SS", "choose": "-- choose --",
        "submit": "Submit report",
        "ok_title": "Case solved! You found the intruder.",
        "ok_text": "You identified the attacker, the compromised account and the moment of the breach, and you chose the right response. Enter this code on the BreachOut platform:",
        "lock_title": "Report locked",
        "lock_text": "You have used all {n} attempts. This room is locked and the challenge is marked as failed. Ask the game master for another try.",
        "warn": "You have {over} of {max} attempts left. Check everything before you submit.",
        "wrong": "Report rejected: <b>{goed} of {totaal}</b> answers are correct. You have <b>{over}</b> attempt(s) left.",
        "attempts": "{n} of {max} attempts left.",
        "al_sev": "CRITICAL", "al_new": "NEW ALERT", "al_ack": "ACKNOWLEDGED",
        "al_recv": "Received", "al_src": "Source",
        "col_no": "No.", "col_time": "Time", "col_proc": "Process", "col_info": "Info",
        "filter_ph": "Apply a display filter  …   e.g.  203.0.113.66   or   Failed password",
        "lg_fail": "Failed login", "lg_ok": "Accepted login", "lg_sess": "Session / sudo", "lg_noise": "Noise / scan",
        "st_all": "{t} events  ·  showing all",
        "st_flt": "{n} of {t} events shown  ·  filter: \"{q}\"",
    },
    "nl": {
        "title": "De inbraak in de logs",
        "nav_alert": "Alert", "nav_log": "auth.log", "nav_report": "Rapport",
        "notes": "Kladblok", "notes_shared": "gedeeld",
        "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "alert_from": "Monitoring <monitoring@ironholdlabs.nl>",
        "alert_subject": "ALERT: veel mislukte SSH-logins op {host}",
        "alert_body": (
            "Het monitoringsysteem zag vannacht een ongewoon hoog aantal mislukte SSH-logins "
            "op de bastion-host {host}. Dit lijkt op een brute-force-aanval.\n\n"
            "Jij hebt dienst. Onderzoek het authenticatielogboek en zoek uit:\n"
            "  1. Welk IP-adres probeerde steeds in te loggen (de aanvaller)?\n"
            "  2. Welk account heeft de aanvaller uiteindelijk gekraakt?\n"
            "  3. Hoe laat kwam de aanvaller binnen?\n"
            "  4. Wat doe je als eerste?\n\n"
            "Open de auth.log (menu hierboven), doorzoek hem, en vul het Rapport in.\n"
            "Tip: gebruik het zoekvak om regels te filteren. Het kladblok staat rechtsonder.\n"
            "Let op: het rapportformulier accepteert maar een paar pogingen."
        ),
        "log_title": "Authenticatielogboek  —  /var/log/auth.log",
        "log_help": "Zoek om regels te filteren (bijv. een IP-adres of \"Failed password\"). De regelnummers staan links.",
        "search_ph": "Zoek in de log...", "download": "auth.log downloaden",
        "lines_total": "{n} regels", "lines_match": "{n} van {t} regels bevatten \"{q}\"",
        "report_title": "Incidentrapport",
        "report_autosave": "Dit rapport wordt automatisch opgeslagen en is gedeeld met je team.",
        "saving": "Opslaan...", "saved": "Opgeslagen en gedeeld met je team.",
        "changes": "Wijzigingen...", "save_failed": "Opslaan mislukt, probeer het opnieuw.",
        "q_ip": "1. IP-adres van de aanvaller (die met veruit de meeste mislukte logins)",
        "q_account": "2. Welk account heeft de aanvaller uiteindelijk gekraakt?",
        "q_tijd": "3. Hoe laat kwam de aanvaller binnen? (UU:MM:SS, uit de 'Accepted password'-regel van dat IP)",
        "q_actie": "4. Wat doe je als eerste?",
        "ph_ip": "bijv. 10.0.0.1", "ph_account": "gebruikersnaam", "ph_tijd": "UU:MM:SS", "choose": "-- kies --",
        "submit": "Rapport versturen",
        "ok_title": "Zaak opgelost! Je hebt de indringer gevonden.",
        "ok_text": "Je hebt de aanvaller, het gekraakte account en het moment van de inbraak gevonden, en de juiste actie gekozen. Vul deze code in op het BreachOut-platform:",
        "lock_title": "Rapport op slot",
        "lock_text": "Je hebt alle {n} pogingen gebruikt. Deze room is op slot en de challenge is gefaald. Vraag de spelleider om een nieuwe poging.",
        "warn": "Je hebt nog {over} van de {max} pogingen. Controleer alles voordat je verstuurt.",
        "wrong": "Rapport afgekeurd: <b>{goed} van de {totaal}</b> antwoorden zijn goed. Je hebt nog <b>{over}</b> poging(en).",
        "attempts": "Nog {n} van de {max} pogingen.",
        "al_sev": "KRITIEK", "al_new": "NIEUWE MELDING", "al_ack": "BEVESTIGD",
        "al_recv": "Ontvangen", "al_src": "Bron",
        "col_no": "Nr.", "col_time": "Tijd", "col_proc": "Proces", "col_info": "Info",
        "filter_ph": "Pas een weergavefilter toe  …   bijv.  203.0.113.66   of   Failed password",
        "lg_fail": "Mislukte login", "lg_ok": "Geslaagde login", "lg_sess": "Sessie / sudo", "lg_noise": "Ruis / scan",
        "st_all": "{t} gebeurtenissen  ·  alles getoond",
        "st_flt": "{n} van {t} getoond  ·  filter: \"{q}\"",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def tr(obj, lang):
    if isinstance(obj, dict):
        if obj and set(obj) <= set(LANGS):
            return obj.get(lang) or obj.get("en") or obj.get("nl") or ""
        return {k: tr(v, lang) for k, v in obj.items()}
    if isinstance(obj, list):
        return [tr(v, lang) for v in obj]
    return obj


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------- de auth.log opbouwen
def hhmmss(sec):
    sec %= 24 * 3600
    return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"


def build_log(data):
    """Bouwt de auth.log deterministisch op uit data['bronnen'] en berekent de
    juiste antwoorden. Bewust lastig: meerdere scannende IP's (de luidste is NIET
    de dader), een extern maar legitiem account, en de echte aanvaller faalt veel
    EN slaagt daarna een keer. Veel ruis ertussen. Geeft terug: (regels, antwoorden)."""
    host = data["host"]
    datum = data["datum"]

    # deterministische "toevalsgenerator" (geen import random, altijd dezelfde log)
    _seed = [1234567]
    def rnd(n):
        _seed[0] = (_seed[0] * 1103515245 + 12345) & 0x7fffffff
        return _seed[0] % n

    bad_users = ["root", "admin", "test", "oracle", "ubuntu", "user", "postgres",
                 "ftp", "mysql", "git", "jenkins", "guest", "pi", "deploy", "operator",
                 "support", "www-data", "nagios", "tomcat", "backup"]

    events = []          # (seconden, regel)
    pid = [2100]
    port = [40000]

    def line(sec, msg):
        pid[0] += 1
        events.append((sec, f"{datum} {hhmmss(sec)} {host} sshd[{pid[0]}]: {msg}"))

    def failed(sec, user, ip, invalid=True):
        port[0] += rnd(30) + 3
        who = f"invalid user {user}" if invalid else user
        line(sec, f"Failed password for {who} from {ip} port {port[0]} ssh2")

    def closed(sec, ip):
        port[0] += rnd(30) + 3
        line(sec, f"Connection closed by authenticating user invalid from {ip} port {port[0]} [preauth]")

    def accepted(sec, user, ip):
        port[0] += rnd(30) + 3
        line(sec, f"Accepted password for {user} from {ip} port {port[0]} ssh2")
        p = pid[0]
        events.append((sec + 1, f"{datum} {hhmmss(sec + 1)} {host} sshd[{p}]: "
                                 f"pam_unix(sshd:session): session opened for user {user} by (uid=0)"))

    answer = {"ip": None, "account": None, "tijd": None, "n_fail": 0}

    # Elke bron over een eigen venster verspreiden, zodat alles door elkaar loopt.
    base = 1 * 3600 + 50 * 60     # ~01:50:00
    for b in data["bronnen"]:
        role = b["role"]
        ip = b["ip"]
        if role in ("scanner", "attacker"):
            users = b.get("users") or bad_users
            n = b["fails"]
            t = base + rnd(600)
            for k in range(n):
                u = users[k % len(users)] if role == "attacker" else bad_users[rnd(len(bad_users))]
                failed(t, u, ip, invalid=(u != b.get("account")))
                # af en toe een losgekoppelde verbinding als ruis
                if rnd(5) == 0:
                    closed(t + 1, ip)
                t += rnd(14) + 4
            if role == "attacker":
                # na het bruteforcen: eindelijk raak op het doelaccount
                acc = b["account"]
                failed(t, acc, ip, invalid=False); t += rnd(8) + 3
                breach = t
                accepted(breach, acc, ip)
                # sporen na de inbraak (bevestigt dat DIT de inbraak is)
                line(breach + 3, f"pam_unix(sshd:session): session opened for user {acc} by (uid=0)")
                line(breach + 12, f"sudo:  {acc} : TTY=pts/1 ; PWD=/home/{acc} ; USER=root ; COMMAND=/bin/bash")
                line(breach + 18, f"pam_unix(sudo:session): session opened for user root by {acc}(uid=0)")
                answer.update(ip=ip, account=acc, tijd=hhmmss(breach), n_fail=b["fails"] + 1)
        elif role in ("legit", "legit_ext"):
            acc = b["account"]
            t = base + rnd(1800)
            for _ in range(b.get("fails", 0)):
                failed(t, acc, ip, invalid=False); t += rnd(10) + 4
            accepted(t, acc, ip)
            # legitieme gebruiker doet gewoon wat werk
            if rnd(2) == 0:
                line(t + rnd(120) + 20, f"pam_unix(sshd:session): session closed for user {acc}")

    # wat algemene systeemruis ertussen
    for _ in range(14):
        tt = base + rnd(3000)
        ip = data["bronnen"][rnd(len(data["bronnen"]))]["ip"]
        kind = rnd(3)
        if kind == 0:
            line(tt, f"Received disconnect from {ip} port {40000 + rnd(2000)}:11: Bye Bye [preauth]")
        elif kind == 1:
            line(tt, f"reverse mapping checking getaddrinfo for host-{rnd(250)}.example.net [{ip}] failed - POSSIBLE BREAK-IN ATTEMPT!")
        else:
            pid[0] += 1
            events.append((tt, f"{datum} {hhmmss(tt)} {host} systemd-logind[640]: New session {rnd(900)} of user alice."))

    events.sort(key=lambda e: e[0])
    regels = [r for _, r in events]
    answer["actie"] = data["antwoorden"]["actie"]
    return regels, answer


# module-cache: de log is deterministisch, dus één keer opbouwen
_LOG = None
_ANTW = None


def get_log():
    global _LOG, _ANTW
    if _LOG is None:
        _LOG, _ANTW = build_log(load())
    return _LOG, _ANTW


def norm(s):
    return re.sub(r"\s+", "", (s or "").strip().lower())


# ------------------------------------------------------------- state
def read_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return {"pogingen": 0, "opgelost": False}


def update_state(fn):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "pogingen.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state = read_state()
        fn(state)
        STATE_FILE.write_text(json.dumps(state), encoding="utf-8")
        return state


# ------------------------------------------------ gedeelde opslag (team)
def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


def read_concept():
    return read_json(CONCEPT_FILE, {"velden": {}, "versie": 0})


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.route("/api/concept", methods=["GET", "PUT"])
def api_concept():
    if request.method == "PUT":
        nieuw = (request.get_json(silent=True) or {}).get("velden", {})
        concept = read_concept()
        for k in FORM_FIELDS:
            if k in nieuw:
                concept["velden"][k] = str(nieuw[k])[:60]
        concept["versie"] = time.time()
        write_json(CONCEPT_FILE, concept)
    return jsonify(read_concept())


@app.context_processor
def common():
    lang = get_lang()
    return {"lang": lang, "t": UI[lang]}


# ------------------------------------------------------------- pagina's
@app.route("/")
def alert():
    data = load()
    return render_template("alert.html", actief="alert", host=data["host"], datum=data["datum"])


@app.route("/log")
def logpagina():
    regels, _ = get_log()
    return render_template("log.html", actief="log", regels=regels, totaal=len(regels))


@app.route("/auth.log")
def download():
    regels, _ = get_log()
    data = "\n".join(regels) + "\n"
    return Response(data, mimetype="text/plain",
                    headers={"Content-Disposition": "attachment; filename=auth.log"})


@app.route("/report", methods=["GET", "POST"])
def report():
    data = load()
    _, antw = get_log()
    state = read_state()
    acties = tr(data["acties"], get_lang())
    ctx = {"actief": "report", "acties": acties}

    if state["opgelost"]:
        return render_template("report.html", status="opgelost",
                               flag=FLAG_FILE.read_text(encoding="utf-8").strip(), **ctx)
    if state["pogingen"] >= data["max_pogingen"]:
        return render_template("report.html", status="slot", max_pogingen=data["max_pogingen"], **ctx)
    if request.method == "GET":
        return render_template("report.html", status="leeg", invoer=read_concept()["velden"],
                               max_pogingen=data["max_pogingen"],
                               pogingen_over=max(0, data["max_pogingen"] - state["pogingen"]), **ctx)

    f = request.form
    # wat verstuurd is, is ook het nieuwe gedeelde concept
    concept = read_concept()
    concept["velden"].update({k: f.get(k, "")[:60] for k in FORM_FIELDS})
    concept["versie"] = time.time()
    write_json(CONCEPT_FILE, concept)

    checks = [
        norm(f.get("ip")) == norm(antw["ip"]),
        norm(f.get("account")) == norm(antw["account"]),
        norm(f.get("tijd")) == norm(antw["tijd"]),
        f.get("actie") == antw["actie"],
    ]
    goed = sum(checks)
    alles_goed = goed == len(checks)

    def bij(s):
        s["pogingen"] += 1
        if alles_goed:
            s["opgelost"] = True
    state = update_state(bij)

    if alles_goed:
        return render_template("report.html", status="opgelost",
                               flag=FLAG_FILE.read_text(encoding="utf-8").strip(), **ctx)
    if state["pogingen"] >= data["max_pogingen"]:
        return render_template("report.html", status="slot", max_pogingen=data["max_pogingen"], **ctx)
    return render_template("report.html", status="fout", goed=goed, totaal=len(checks),
                           invoer=f, over=data["max_pogingen"] - state["pogingen"],
                           max_pogingen=data["max_pogingen"], **ctx)


@app.route("/api/flag")
def api_flag():
    """Door het BreachOut-platform opgehaald (spelleider) om de unieke flag van
    deze draaiende room te kunnen tonen. Alleen de webserver kan dit IP bereiken."""
    try:
        return jsonify(flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
