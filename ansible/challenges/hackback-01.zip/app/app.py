"""
BreachOut escaperoom: Hack Back: ShinyHunters (hackback-01)

Difficult incident-response challenge. NEP-terminal + nep-adminpaneel; er wordt
niets echt gehackt.

Act 1 (terminal): verken het systeem, vind de blunders van de aanvaller in
.bash_history, decrypt je bestanden, connect met hun C2 en gebruik 'killswitch'.
Act 2 (web): 'restore-admin' opent het adminpaneel. ShinyHunters zijn opnieuw
binnen -> verbreek snel hun sessie, verander admin-wachtwoord (16+ tekens) en
-e-mail binnen 1 minuut, en sla het wachtwoord op in de digitale kluis. Pas dan
verschijnt de flag (server-side).

Beginner-vriendelijk: elk terminal-commando heeft een '#'-uitleg via 'help'.
Taal: EN (standaard) of NL via cookie room_lang.
"""
import fcntl
import json
import re
import time
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request

BASE = Path("/opt/hackback")
DATA_FILE = BASE / "data.json"
FLAG_FILE = BASE / "flag.txt"
STATE_DIR = BASE / "state"
STATE_FILE = STATE_DIR / "progress.json"
NOTES_FILE = STATE_DIR / "kladblok.json"
NOTES_MAX = 20000

app = Flask(__name__)
LANGS = ("en", "nl")

UI = {
    "en": {
        "title": "ShinyHunters // compromised host",
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "ransom": "YOUR SYSTEMS ARE LOCKED BY SHINYHUNTERS",
        "ransom_sub": "Limited shell access remaining. Recover control before the timer runs out.",
        "prompt_hint": "Type  help  and press Enter to begin.",
        "unknown": "{c}: unknown command. Type 'help' to see what you can do.",
        "whoami": "guest   (your 'admin' rights were taken by the attacker)\n# Tip: look around with  ls  — and don't forget hidden files.",
        "help": (
            "Available commands:\n"
            "  help                 # show this list\n"
            "  whoami               # show who you are\n"
            "  ls                   # list the files in this folder\n"
            "  ls -a                # ALSO list hidden files (names starting with a dot)\n"
            "  cat <file>           # show the contents of a file\n"
            "  ps                   # list running processes (running programs)\n"
            "  netstat              # list active network connections\n"
            "  history              # show previously typed commands\n"
            "  decrypt <key>        # decrypt your files with a key\n"
            "  connect <ip> <pw>    # connect to a server (ip + password)\n"
            "  killswitch           # cut off the attacker's access\n"
            "  clear                # clear the screen\n"
            "\n# Goal: find the attacker's mistakes, decrypt your files, connect to their\n"
            "# server and hit the killswitch. Start with  ls -a  and  cat .\n"
        ),
        "ls_tip": "\n# Tip: a file might be hidden. Try  ls -a  . And read files with  cat <file>.",
        "cat_missing": "cat: {f}: no such file",
        "enc_locked": "<encrypted data — unreadable>\n# Tip: first find the key and run  decrypt <key>.",
        "bash_tip": "\n# Tip: the attacker left a key AND a password here. Use  decrypt <key>  , then  connect <ip> <pw>.",
        "ps_tip": "\n# Tip: 'cat .bash_history' to see what the attacker typed.",
        "decrypt_ok": "Files restored successfully. Your documents are readable again.\n# Next step: kick the attacker out. Connect to their C2 server with  connect <ip> <pw>.",
        "decrypt_bad": "decrypt: wrong key. Look again in the attacker's history.",
        "decrypt_usage": "usage: decrypt <key>",
        "connect_ok": "Connected to C2 panel at {ip}. You are inside the attacker's server.\n# Final step: run  killswitch  to cut off their access.",
        "connect_bad": "connect: connection refused (wrong ip or password). Check .bash_history again.",
        "connect_usage": "usage: connect <ip> <password>",
        "killswitch_need": "killswitch: you are not connected to the C2 panel yet. Use  connect <ip> <pw>  first.",
        "killswitch_ok": (
            "Revoking ShinyHunters access... done.\n"
            "But they tampered with your ADMIN PANEL. You must take it back.\n\n"
            "# Run this command to restore your admin panel:\n"
            "    restore-admin\n"
        ),
        "restore_need": "restore-admin: nothing to restore yet. Use  killswitch  first.",
        "restore_ok": "Admin panel restored. Open it below and act fast — they are still trying to get back in.",
        "hint_err": "Something went wrong. Type 'help' and try again.",
        "hint_encrypt": "That is the attacker's OWN ransomware script — you don't run it.\n# You already found the key in their history. Use it like this:  decrypt <key>",
        "hint_sshpass": "You don't need sshpass here.\n# To log in to their server, use:  connect <ip> <password>  (both are in .bash_history)",
    },
    "nl": {
        "title": "ShinyHunters // gecompromitteerde host",
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "ransom": "JE SYSTEMEN ZIJN VERGRENDELD DOOR SHINYHUNTERS",
        "ransom_sub": "Je hebt nog beperkte terminal-toegang. Herover de controle voor de tijd om is.",
        "prompt_hint": "Typ  help  en druk op Enter om te beginnen.",
        "unknown": "{c}: onbekend commando. Typ 'help' om te zien wat je kunt doen.",
        "whoami": "guest   (je 'admin'-rechten zijn afgepakt door de aanvaller)\n# Tip: kijk rond met  ls  — en vergeet verborgen bestanden niet.",
        "help": (
            "Beschikbare commando's:\n"
            "  help                 # toont deze lijst\n"
            "  whoami               # laat zien wie je bent\n"
            "  ls                   # toont de bestanden in deze map\n"
            "  ls -a                # toont OOK verborgen bestanden (naam begint met een punt)\n"
            "  cat <bestand>        # toont de inhoud van een bestand\n"
            "  ps                   # toont actieve processen (draaiende programma's)\n"
            "  netstat              # toont actieve netwerkverbindingen\n"
            "  history              # toont eerder getypte commando's\n"
            "  decrypt <sleutel>    # ontsleutelt je bestanden met een sleutel\n"
            "  connect <ip> <ww>    # verbindt met een server (ip + wachtwoord)\n"
            "  killswitch           # schakelt de toegang van de aanvaller uit\n"
            "  clear                # maakt het scherm leeg\n"
            "\n# Doel: vind de fouten van de aanvaller, ontsleutel je bestanden, verbind met\n"
            "# hun server en gebruik de killswitch. Begin met  ls -a  en  cat .\n"
        ),
        "ls_tip": "\n# Tip: misschien is er een verborgen bestand. Probeer  ls -a  . Lees bestanden met  cat <bestand>.",
        "cat_missing": "cat: {f}: bestaat niet",
        "enc_locked": "<versleutelde data — onleesbaar>\n# Tip: zoek eerst de sleutel en gebruik  decrypt <sleutel>.",
        "bash_tip": "\n# Tip: de aanvaller liet hier een sleutel EN een wachtwoord achter. Gebruik  decrypt <sleutel>  , daarna  connect <ip> <ww>.",
        "ps_tip": "\n# Tip: 'cat .bash_history' om te zien wat de aanvaller typte.",
        "decrypt_ok": "Bestanden succesvol hersteld. Je documenten zijn weer leesbaar.\n# Volgende stap: schop de aanvaller eruit. Verbind met hun C2-server via  connect <ip> <ww>.",
        "decrypt_bad": "decrypt: verkeerde sleutel. Kijk nog eens in de history van de aanvaller.",
        "decrypt_usage": "gebruik: decrypt <sleutel>",
        "connect_ok": "Verbonden met C2-paneel op {ip}. Je zit in de server van de aanvaller.\n# Laatste stap: gebruik  killswitch  om hun toegang af te snijden.",
        "connect_bad": "connect: verbinding geweigerd (verkeerd ip of wachtwoord). Check .bash_history nog eens.",
        "connect_usage": "gebruik: connect <ip> <wachtwoord>",
        "killswitch_need": "killswitch: je bent nog niet verbonden met het C2-paneel. Gebruik eerst  connect <ip> <ww>.",
        "killswitch_ok": (
            "Toegang ShinyHunters intrekken... gelukt.\n"
            "Maar ze hebben je ADMIN-PANEEL aangetast. Je moet het terugpakken.\n\n"
            "# Voer dit commando uit om je adminpaneel te herstellen:\n"
            "    restore-admin\n"
        ),
        "restore_need": "restore-admin: er is nog niets te herstellen. Gebruik eerst  killswitch.",
        "restore_ok": "Adminpaneel hersteld. Open het hieronder en handel snel — ze proberen nog steeds terug te komen.",
        "hint_err": "Er ging iets mis. Typ 'help' en probeer opnieuw.",
        "hint_encrypt": "Dit is het EIGEN ransomware-script van de aanvaller — dat voer je niet uit.\n# Je hebt de sleutel al in hun history gevonden. Gebruik hem zo:  decrypt <sleutel>",
        "hint_sshpass": "Je hebt sshpass hier niet nodig.\n# Om op hun server in te loggen gebruik je:  connect <ip> <wachtwoord>  (beide staan in .bash_history)",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def tr(obj, lang):
    if isinstance(obj, dict) and obj and set(obj) <= set(LANGS):
        return obj.get(lang) or obj.get("en") or ""
    return obj


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)


DEFAULT_STATE = {"decrypted": False, "connected": False, "ks_done": False,
                 "restored": False, "blocked": False, "hardened": False,
                 "hardened_pw": "", "vaulted": False}


def read_state():
    try:
        st = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return {**DEFAULT_STATE, **st}
    except (FileNotFoundError, ValueError):
        return dict(DEFAULT_STATE)


def update_state(fn):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "progress.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        st = read_state()
        fn(st)
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(st), encoding="utf-8")
        tmp.replace(STATE_FILE)        # atomische schrijf
        return st


# --------------------------------------------------------------- Act 1: terminal
@app.route("/")
def index():
    lang = get_lang()
    return render_template("terminal.html", t=UI[lang], lang=lang)


@app.route("/api/cmd", methods=["POST"])
def api_cmd():
    lang = get_lang()
    t = UI[lang]
    try:
        data = load()
        tx = data["teksten"]
        raw = ((request.get_json(silent=True) or {}).get("cmd") or "").strip()
        if not raw:
            return jsonify(out="")
        parts = raw.split()
        word = parts[0].lower()
        args = parts[1:]

        if word == "help":
            return jsonify(out=t["help"])
        if word == "clear":
            return jsonify(clear=True)
        if word == "whoami":
            return jsonify(out=t["whoami"])
        if word == "ls":
            files = list(data["bestanden"])
            if args and args[0] in ("-a", "-la", "-al"):
                return jsonify(out="  ".join([".bash_history"] + files))
            return jsonify(out="  ".join(files) + t["ls_tip"])
        if word in ("cat", "less", "more"):
            if not args:
                return jsonify(out=t["cat_missing"].format(f=""))
            f = args[0]
            if f == "README_SHINYHUNTERS.txt":
                return jsonify(out=tr(tx["readme"], lang))
            if f == "server.log":
                return jsonify(out=tr(tx["serverlog"], lang))
            if f in (".bash_history", "bash_history"):
                return jsonify(out=tr(tx["bashhistory"], lang) + t["bash_tip"])
            if f == "documenten.encrypted":
                if read_state()["decrypted"]:
                    return jsonify(out="personeel.xlsx, contracten.pdf, back-ups ... (hersteld / restored)")
                return jsonify(out=t["enc_locked"])
            return jsonify(out=t["cat_missing"].format(f=f))
        if word == "ps":
            return jsonify(out=tr(tx["ps"], lang) + t["ps_tip"])
        if word == "netstat":
            return jsonify(out=tr(tx["netstat"], lang))
        if word == "history":
            return jsonify(out=tr(tx["bashhistory"], lang) + t["bash_tip"])
        if word == "decrypt":
            if not args:
                return jsonify(out=t["decrypt_usage"])
            if args[0] == data["decrypt_key"]:
                update_state(lambda s: s.update(decrypted=True))
                return jsonify(out=t["decrypt_ok"])
            return jsonify(out=t["decrypt_bad"])
        if word == "connect":
            if len(args) < 2:
                return jsonify(out=t["connect_usage"])
            if args[0] == data["c2_ip"] and args[1] == data["c2_pw"]:
                update_state(lambda s: s.update(connected=True))
                return jsonify(out=t["connect_ok"].format(ip=data["c2_ip"]))
            return jsonify(out=t["connect_bad"])
        if word == "killswitch":
            if not read_state()["connected"]:
                return jsonify(out=t["killswitch_need"])
            update_state(lambda s: s.update(ks_done=True))
            return jsonify(out=t["killswitch_ok"])
        if word in ("restore-admin", "restore_admin", "./restore-admin"):
            if not read_state()["ks_done"]:
                return jsonify(out=t["restore_need"])
            update_state(lambda s: s.update(restored=True))
            return jsonify(out=t["restore_ok"], link="admin")
        # Vergevingsgezind: ving de letterlijke aanvaller-commando's op en geef een hint
        if "encrypt_all.sh" in raw.lower():
            return jsonify(out=t["hint_encrypt"])
        if word == "sshpass":
            return jsonify(out=t["hint_sshpass"])
        return jsonify(out=t["unknown"].format(c=word))
    except Exception:
        app.logger.exception("api_cmd fout")
        return jsonify(out=t["hint_err"])


# --------------------------------------------------------------- Act 2: adminpaneel
@app.route("/admin")
def admin():
    if not read_state()["restored"]:
        return redirect("./")
    data = load()
    lang = get_lang()
    return render_template("admin.html", t=UI[lang], lang=lang,
                           st=read_state(), oud_email=data["admin"]["oud_email"])


@app.route("/api/block", methods=["POST"])
def api_block():
    if not read_state()["restored"]:
        return jsonify(ok=False), 400
    update_state(lambda s: s.update(blocked=True))
    return jsonify(ok=True)


@app.route("/harden")
def harden():
    if not read_state()["blocked"]:
        return redirect("admin")
    data = load()
    lang = get_lang()
    return render_template("harden.html", t=UI[lang], lang=lang,
                           oud_email=data["admin"]["oud_email"], gebruiker=data["admin"]["gebruiker"])


def pw_checks(pw):
    return {
        "len": len(pw) >= 16,
        "upper": bool(re.search(r"[A-Z]", pw)),
        "lower": bool(re.search(r"[a-z]", pw)),
        "digit": bool(re.search(r"\d", pw)),
        "special": bool(re.search(r"[^A-Za-z0-9]", pw)),
    }


@app.route("/api/harden", methods=["POST"])
def api_harden():
    if not read_state()["blocked"]:
        return jsonify(ok=False, error="volgorde"), 400
    data = load()
    body = request.get_json(silent=True) or {}
    pw = str(body.get("pw", ""))
    email = str(body.get("email", "")).strip().lower()
    checks = pw_checks(pw)
    errs = []
    if not all(checks.values()):
        errs.append("pw")
    # e-mail moet geldig zijn, van je eigen domein, en NIET het adres van de aanvaller
    if (not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email)
            or "shinyhunters" in email
            or email == data["admin"]["oud_email"].lower()
            or not email.endswith("@ironholdlabs.nl")):
        errs.append("email")
    if errs:
        return jsonify(ok=False, checks=checks, errors=errs)
    update_state(lambda s: s.update(hardened=True, hardened_pw=pw))
    return jsonify(ok=True)


@app.route("/vault")
def vault():
    if not read_state()["hardened"]:
        return redirect("harden")
    lang = get_lang()
    return render_template("vault.html", t=UI[lang], lang=lang, gebruiker=load()["admin"]["gebruiker"])


@app.route("/api/vault", methods=["POST"])
def api_vault():
    st = read_state()
    if not st["hardened"]:
        return jsonify(ok=False, error="volgorde"), 400
    body = request.get_json(silent=True) or {}
    titel = str(body.get("titel", "")).strip()
    gebruiker = str(body.get("gebruiker", "")).strip()
    pw = str(body.get("pw", ""))
    if not titel or not gebruiker:
        return jsonify(ok=False, error="leeg")
    if pw != st["hardened_pw"]:
        return jsonify(ok=False, error="mismatch")
    update_state(lambda s: s.update(vaulted=True))
    return jsonify(ok=True, flag=load()["flag"])


@app.route("/api/flag")
def api_flag():
    try:
        return jsonify(flag=load()["flag"])
    except Exception:
        return jsonify(flag=None)


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    """Gedeeld kladblok voor het team (server-side, zodat teamgenoten het ook zien)."""
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
