"""
BreachOut escaperoom: Mark's Last Working Day (mark-case-01)

Difficult forensische challenge. De speler onderzoekt een forensische kopie van
de werkplek van een ontslagen medewerker (Mark de Vries) en reconstrueert een
datadiefstal:

  1. Bureaublad-kopie met een verdacht, met wachtwoord beveiligd
     backup_belangrijk.zip (te downloaden).
  2. Het zip-wachtwoord staat verstopt in een mail die Mark zichzelf stuurde.
  3. In de zip: klantgegevens + een notitie met het mailadres van de concurrent
     en een deadline.
  4. FLAG = flag{<mailnaam>-gmail_<dd-mm-jjjj>}  (afgeleid en vast).

De flag is AFGELEID uit de inhoud en voor iedereen gelijk; hij wordt bij
registratie als vaste flag ingevuld (niet per team gegenereerd).

Taal: Engels (standaard) of Nederlands, volgt het platform via cookie room_lang.
Alle links zijn relatief, zodat de app werkt achter de webserver-proxy.
"""
import json
from pathlib import Path

import time
import fcntl
from flask import Flask, abort, jsonify, render_template, request, send_file

BASE = Path("/opt/markcase")
STATE_DIR = BASE / "state"
NOTES_FILE = STATE_DIR / "kladblok.json"
NOTES_MAX = 20000
DATA_FILE = BASE / "data.json"
ZIP_FILE = BASE / "static" / "backup_belangrijk.zip"

app = Flask(__name__)
LANGS = ("en", "nl")

UI = {
    "en": {
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "brand": "ForensiCase", "case": "Case: suspected data theft",
        "nav_inbox": "Mailbox", "nav_evidence": "Desktop (forensic copy)",
        "subject": "Subject", "from": "From", "to": "To", "date": "Date", "open": "Open",
        "inbox_title": "Mailbox — m.devries@ironholdlabs.nl",
        "inbox_hint": "Three messages were recovered from the suspect's mailbox. Read them carefully.",
        "ev_title": "Desktop of m.devries (forensic copy)",
        "ev_hint": "Files found on the suspect's desktop. Only the archive can be exported for analysis.",
        "name": "Name", "size": "Size", "modified": "Modified", "download": "Download",
        "back": "Back to mailbox", "note": "This is a read-only forensic copy.",
    },
    "nl": {
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "brand": "ForensiCase", "case": "Zaak: vermoedelijke datadiefstal",
        "nav_inbox": "Mailbox", "nav_evidence": "Bureaublad (forensische kopie)",
        "subject": "Onderwerp", "from": "Van", "to": "Aan", "date": "Datum", "open": "Openen",
        "inbox_title": "Mailbox — m.devries@ironholdlabs.nl",
        "inbox_hint": "Drie berichten zijn teruggehaald uit de mailbox van de verdachte. Lees ze goed.",
        "ev_title": "Bureaublad van m.devries (forensische kopie)",
        "ev_hint": "Bestanden op het bureaublad van de verdachte. Alleen het archief kan geëxporteerd worden voor analyse.",
        "name": "Naam", "size": "Grootte", "modified": "Gewijzigd", "download": "Downloaden",
        "back": "Terug naar mailbox", "note": "Dit is een alleen-lezen forensische kopie.",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def tr(obj, lang):
    if isinstance(obj, dict):
        if obj and set(obj) <= set(LANGS):
            return obj.get(lang) or obj.get("en") or ""
        return {k: tr(v, lang) for k, v in obj.items()}
    if isinstance(obj, list):
        return [tr(v, lang) for v in obj]
    return obj


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)



def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    """Gedeeld kladblok voor het team (server-side, zodat teamgenoten het ook zien)."""
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.context_processor
def common():
    lang = get_lang()
    return {"lang": lang, "t": UI[lang]}


@app.route("/")
def inbox():
    data = load()
    lang = get_lang()
    mails = [{"id": m["id"], "van": m["van"], "datum": m["datum"],
              "onderwerp": tr(m["onderwerp"], lang)} for m in data["mails"]]
    return render_template("inbox.html", actief="inbox", mails=mails)


@app.route("/mail")
def mail():
    data = load()
    lang = get_lang()
    try:
        mid = int(request.args.get("id", ""))
    except (TypeError, ValueError):
        abort(404)
    m = next((x for x in data["mails"] if int(x["id"]) == mid), None)
    if not m:
        abort(404)
    msg = {"van": m["van"], "aan": m["aan"], "datum": m["datum"],
           "onderwerp": tr(m["onderwerp"], lang), "tekst": tr(m["tekst"], lang)}
    return render_template("mail.html", actief="inbox", m=msg)


@app.route("/evidence")
def evidence():
    data = load()
    return render_template("evidence.html", actief="evidence", bestanden=data["bestanden"])


@app.route("/download/backup_belangrijk.zip")
def download():
    if not ZIP_FILE.exists():
        abort(404)
    return send_file(str(ZIP_FILE), as_attachment=True,
                     download_name="backup_belangrijk.zip", mimetype="application/zip")


@app.route("/api/flag")
def api_flag():
    """Door het BreachOut-platform opgehaald (spelleider) om de (afgeleide, vaste)
    flag van deze challenge te kunnen tonen."""
    try:
        return jsonify(flag=load()["flag"])
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
