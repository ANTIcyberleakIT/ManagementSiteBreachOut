"""
BreachOut escaperoom: De Kerstborrel-hack (kerstborrel-01)

Intermediate access-control challenge. Vlak voor de kerstborrel is de Secret
Santa-aanmeldpagina aangepast en zijn alle cadeautjes omgewisseld. De speler
ontmaskert de dader door te LEZEN en bewijs te combineren:

  /            aanmeldpagina — "laatst gewijzigd: vandaag 16:47" is verdacht laat
  /log         wijzigingslog — de 16:47-wijziging kwam van account hr.tijdelijk
  /portal      personeelsportal — zoek hr.tijdelijk: oud stagiair-account, nooit uitgezet
  /plattegrond kantoorplattegrond — IP 10.12.8.x = Vergaderzaal "De Noordpool"
  /melden      meldformulier — account + locatie + oorzaak -> flag (cadeaubonnetje)

Er wordt niets echt aangevallen; de speler oefent met lezen, zoeken en
combineren. De flag komt alleen server-side uit een correcte melding.

Taal: Engels (standaard) of Nederlands, volgt het platform via cookie room_lang.
Alle links zijn relatief, zodat de app werkt achter de webserver-proxy op
/room/<token>/.
"""
import fcntl
import json
import time
from pathlib import Path

from flask import Flask, jsonify, render_template, request

BASE = Path("/opt/santa")
DATA_FILE = BASE / "data.json"
FLAG_FILE = BASE / "flag.txt"
STATE_DIR = BASE / "state"
STATE_FILE = STATE_DIR / "pogingen.json"
NOTES_FILE = STATE_DIR / "kladblok.json"
CONCEPT_FILE = STATE_DIR / "concept.json"
NOTES_MAX = 20000
FORM_FIELDS = ("account", "locatie", "oorzaak")   # velden van het meldformulier

app = Flask(__name__)
LANGS = ("en", "nl")

UI = {
    "en": {
        "nav_home": "Sign-up", "nav_log": "Change log", "nav_portal": "Staff portal",
        "nav_map": "Office map", "nav_report": "Report incident",
        "foot": "IronHold Labs BV — internal Secret Santa tool. Systems are logged.",
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        # home
        "home_title": "🎄 Secret Santa — Christmas party",
        "home_lead": "Sign up and see who gives a gift to whom. The party starts soon!",
        "changed": "last changed: today {t}",
        "changed_note": "Managed by {who}, who works until {until}.",
        "th_from": "Gives a gift", "th_to": "to",
        "home_hint": "Something feels off about this list. When was it last changed, and by whom? Check the change log.",
        # log
        "log_title": "Change log — Secret Santa list",
        "log_lead": "Every change to the list is recorded here.",
        "th_time": "Time", "th_account": "Account", "th_ip": "IP address", "th_action": "Action",
        "log_hint": "One change stands out: a different account, late in the day. Look up that account in the staff portal.",
        # portal
        "portal_title": "Staff portal — account lookup",
        "portal_lead": "Search for an account to see who it belongs to.",
        "search_ph": "e.g. hr.tijdelijk",
        "search_btn": "Search",
        "no_result": "No account found for '{q}'. Tip: type the exact account name from the change log.",
        "col_user": "Account", "col_name": "Name", "col_role": "Role", "col_status": "Status",
        "col_created": "Created", "col_last": "Last login", "col_ip": "Known IP", "col_note": "Note",
        "portal_hint": "This account has a known IP. Does it match the IP of the 16:47 change? Check the office map.",
        # map
        "map_title": "Office map — Wi-Fi zones",
        "map_lead": "Each part of the office has its own Wi-Fi zone and IP range.",
        "th_range": "IP range", "th_zone": "Zone / room",
        "map_hint": "Match the IP of the 16:47 change to a zone. Then report what you found.",
        # report
        "report_title": "Report the incident",
        "report_lead": "You investigated the hack. Fill in your conclusion to raise the alarm before the party.",
        "f_account": "Which account was misused?",
        "f_account_ph": "account name",
        "f_locatie": "From which location was the change made?",
        "f_locatie_ph": "room / zone",
        "f_oorzaak": "How could this happen?",
        "opt_choose": "— choose —",
        "opt_phish": "Someone guessed Sanne's password",
        "opt_stale": "A leaver's temporary account was never disabled",
        "opt_virus": "A virus changed the list automatically",
        "opt_bug": "A bug in the Secret Santa tool",
        "submit": "Submit report",
        "wrong": "That doesn't match the evidence yet. Re-read the log, portal and map. {n} attempt(s) left.",
        "locked_title": "Report locked",
        "locked_text": "Too many incorrect reports. This form is locked and the challenge is marked as failed. Ask the game master for another try.",
        # success (cadeaubonnetje)
        "ok_title": "Incident confirmed — nice work!",
        "ok_text": "You unmasked the method: the old intern account 'hr.tijdelijk' was never disabled and was used from the meeting room. Here is your reward, wrapped as a gift voucher:",
        "voucher_title": "🎁 GIFT VOUCHER",
        "voucher_sub": "IronHold Labs — Christmas party",
        "voucher_for": "Awarded to the sharp-eyed investigator",
        "flag_label": "Your flag:",
        "ok_platform": "Enter this flag on the BreachOut platform.",
    },
    "nl": {
        "nav_home": "Aanmelden", "nav_log": "Wijzigingslog", "nav_portal": "Personeelsportal",
        "nav_map": "Plattegrond", "nav_report": "Incident melden",
        "foot": "IronHold Labs BV — interne Secret Santa-tool. Systemen worden gelogd.",
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "home_title": "🎄 Secret Santa — kerstborrel",
        "home_lead": "Meld je aan en zie wie wie een cadeautje geeft. De borrel begint zo!",
        "changed": "laatst gewijzigd: vandaag {t}",
        "changed_note": "Beheerd door {who}, die werkt tot {until}.",
        "th_from": "Geeft een cadeau", "th_to": "aan",
        "home_hint": "Er klopt iets niet aan deze lijst. Wanneer is hij voor het laatst gewijzigd, en door wie? Bekijk de wijzigingslog.",
        "log_title": "Wijzigingslog — Secret Santa-lijst",
        "log_lead": "Elke wijziging aan de lijst wordt hier vastgelegd.",
        "th_time": "Tijd", "th_account": "Account", "th_ip": "IP-adres", "th_action": "Actie",
        "log_hint": "Eén wijziging valt op: een ander account, laat op de dag. Zoek dat account op in de personeelsportal.",
        "portal_title": "Personeelsportal — account opzoeken",
        "portal_lead": "Zoek een account om te zien van wie het is.",
        "search_ph": "bijv. hr.tijdelijk",
        "search_btn": "Zoeken",
        "no_result": "Geen account gevonden voor '{q}'. Tip: typ de exacte accountnaam uit de wijzigingslog.",
        "col_user": "Account", "col_name": "Naam", "col_role": "Rol", "col_status": "Status",
        "col_created": "Aangemaakt", "col_last": "Laatste login", "col_ip": "Bekend IP", "col_note": "Opmerking",
        "portal_hint": "Dit account heeft een bekend IP. Komt dat overeen met het IP van de 16:47-wijziging? Bekijk de plattegrond.",
        "map_title": "Kantoorplattegrond — wifi-zones",
        "map_lead": "Elk deel van kantoor heeft een eigen wifi-zone en IP-reeks.",
        "th_range": "IP-reeks", "th_zone": "Zone / ruimte",
        "map_hint": "Koppel het IP van de 16:47-wijziging aan een zone. Meld daarna wat je vond.",
        "report_title": "Meld het incident",
        "report_lead": "Je onderzocht de hack. Vul je conclusie in om alarm te slaan vóór de borrel.",
        "f_account": "Welk account is misbruikt?",
        "f_account_ph": "accountnaam",
        "f_locatie": "Vanaf welke locatie is de wijziging gedaan?",
        "f_locatie_ph": "ruimte / zone",
        "f_oorzaak": "Hoe kon dit gebeuren?",
        "opt_choose": "— kies —",
        "opt_phish": "Iemand raadde het wachtwoord van Sanne",
        "opt_stale": "Het tijdelijke account van een vertrokken stagiair was nooit uitgezet",
        "opt_virus": "Een virus wijzigde de lijst automatisch",
        "opt_bug": "Een bug in de Secret Santa-tool",
        "submit": "Melding versturen",
        "wrong": "Dit past nog niet bij het bewijs. Lees de log, portal en plattegrond opnieuw. Nog {n} poging(en).",
        "locked_title": "Melding geblokkeerd",
        "locked_text": "Te veel foute meldingen. Dit formulier is op slot en de challenge is gefaald. Vraag de spelleider om een nieuwe poging.",
        "ok_title": "Incident bevestigd — goed gedaan!",
        "ok_text": "Je ontmaskerde de methode: het oude stagiair-account 'hr.tijdelijk' was nooit uitgezet en werd gebruikt vanuit de vergaderzaal. Hier is je beloning, verpakt als cadeaubonnetje:",
        "voucher_title": "🎁 CADEAUBON",
        "voucher_sub": "IronHold Labs — kerstborrel",
        "voucher_for": "Toegekend aan de scherpe speurneus",
        "flag_label": "Je flag:",
        "ok_platform": "Vul deze flag in op het BreachOut-platform.",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)


def read_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return {"pogingen": 0, "opgelost": False}


def update_state(fn):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "pogingen.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state = read_state()
        fn(state)
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(state), encoding="utf-8")
        tmp.replace(STATE_FILE)
        return state


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    """Gedeeld kladblok voor het team (server-side, zodat teamgenoten het ook zien)."""
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.route("/api/concept", methods=["GET", "PUT"])
def api_concept():
    """Bewaart ingevulde formuliervelden, zodat ze blijven staan bij navigeren."""
    concept = read_json(CONCEPT_FILE, {"velden": {}, "versie": 0})
    if request.method == "PUT":
        nieuw = (request.get_json(silent=True) or {}).get("velden", {})
        for k in FORM_FIELDS:
            if k in nieuw:
                concept["velden"][k] = str(nieuw[k])[:80]
        concept["versie"] = time.time()
        write_json(CONCEPT_FILE, concept)
    return jsonify(concept)


@app.context_processor
def common():
    lang = get_lang()
    data = load()
    return {"lang": lang, "t": UI[lang], "bedrijf": data["bedrijf"], "root": ""}


@app.route("/")
def home():
    data = load()
    return render_template("home.html", actief="home", data=data)


@app.route("/log")
def log():
    return render_template("log.html", actief="log", rows=load()["log"])


@app.route("/portal")
def portal():
    data = load()
    q = (request.args.get("q") or "").strip()
    gevonden = None
    if q:
        for a in data["accounts"]:
            if a["gebruiker"].lower() == q.lower():
                gevonden = a
                break
    return render_template("portal.html", actief="portal", q=q, acc=gevonden,
                           gezocht=bool(q))


@app.route("/plattegrond")
def plattegrond():
    return render_template("plattegrond.html", actief="map", zones=load()["zones"])


@app.route("/melden", methods=["GET", "POST"])
def melden():
    data = load()
    ant = data["antwoord"]
    maxp = data["max_pogingen"]
    state = read_state()

    if state["opgelost"]:
        return render_template("success.html", actief="report", flag=data["flag"])
    if state["pogingen"] >= maxp:
        return render_template("melden.html", actief="report", status="slot")

    if request.method == "POST":
        account = (request.form.get("account") or "").strip().lower()
        locatie = (request.form.get("locatie") or "").strip().lower()
        oorzaak = (request.form.get("oorzaak") or "").strip()

        account_ok = account == ant["account"].lower()
        locatie_ok = any(w in locatie for w in ant["locatie_woorden"])
        oorzaak_ok = oorzaak == ant["oorzaak"]
        goed = account_ok and locatie_ok and oorzaak_ok

        def bij(s):
            if goed:
                s["opgelost"] = True
            else:
                s["pogingen"] += 1
        state = update_state(bij)

        if goed:
            return render_template("success.html", actief="report", flag=data["flag"])
        if state["pogingen"] >= maxp:
            return render_template("melden.html", actief="report", status="slot")
        return render_template("melden.html", actief="report", status="fout",
                               over=maxp - state["pogingen"],
                               account=request.form.get("account", ""),
                               locatie=request.form.get("locatie", ""))

    return render_template("melden.html", actief="report", status="leeg")


@app.route("/api/flag")
def api_flag():
    """Door het platform opgehaald (spelleider) om de flag van deze room te tonen."""
    try:
        return jsonify(flag=load()["flag"])
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
