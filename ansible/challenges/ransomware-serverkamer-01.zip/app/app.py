"""
BreachOut escaperoom: Ransomware op de serverkamer (ransomware-serverkamer-01)

Meerfasige terminal-room (zoals hackback). NIETS wordt echt versleuteld/gehackt;
alle terminal-output is vooraf gemaakt. Fasen:

  FASE 1  /backup  (2 min)  BACKUP-01 terug-hacken met commando's + zoekwerk.
                            Op tijd -> groene "slot gaat open"-animatie -> fase 2.
                            Te laat -> /betalen -> fase 2.
  FASE 2  /wallet  (5 min)  de BTC-wallet van Rick terug-hacken -> je krijgt de FLAG.
  FASE 3  /aanval  (2 min)  tweede ShinyHunters-aanval; na het laatste commando is
                            BACKUP-01 definitief versleuteld/kwijt.
  /teruggeven               geef de herstelde wallet terug aan Rick.
  /aangifte                 lever als laatste de FLAG in die je bij de wallet kreeg.

Twee flags: backup op tijd -> flag_goed (vol). Backup mislukt + betaald -> flag_duur (half).
Alle tijden server-gecontroleerd. Taal EN/NL via cookie room_lang.
"""
import fcntl
import json
import time
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request

BASE = Path("/opt/lockdown")
DATA_FILE = BASE / "data.json"
FLAG_FILE = BASE / "flag.txt"
STATE_DIR = BASE / "state"
STATE_FILE = STATE_DIR / "voortgang.json"
NOTES_FILE = STATE_DIR / "kladblok.json"
CONCEPT_FILE = STATE_DIR / "concept.json"
NOTES_MAX = 20000
FORM_FIELDS = ("flag",)

app = Flask(__name__)
LANGS = ("en", "nl")

UI = {
    "en": {
        "brand": "IronHold Labs — SOC",
        "nav_screen": "The screen", "nav_backup": "1. Backup", "nav_wallet": "2. Wallet",
        "nav_aanval": "3. Attack", "nav_report": "Police report",
        "foot": "IronHold Labs — Security Operations. Simulation only; nothing is really encrypted.",
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "ransom_title": "ALL YOUR FILES HAVE BEEN ENCRYPTED",
        "ransom_body": "Your servers are locked by {fam}. Pay {eur} EUR ({btc} BTC) within {hrs} hours or lose everything.",
        "ransom_addr": "Send Bitcoin to:",
        "deadline": "Deadline",
        "chat_title": "Service desk",
        "chat_1": "{who} runs in, out of breath:",
        "chat_rick1": "Everything's encrypted! And my crypto wallet was linked to my work laptop — my seed was in a document. They stole {amt} in Bitcoin from me!",
        "chat_rick2": "Please — can you hack it all back?!",
        "chat_you": "You (first responder):",
        "chat_opt_pay": "Panic and pay them",
        "chat_opt_calm": "Stay calm — open the response console",
        "chat_badpay": "Paying first is what they want. Keep your head — try to take the backup back first.",
        "chat_go": "Let's go. BACKUP-01 is still restorable. Open the console and reclaim it before it's too late.",
        "start_btn": "Open the response console →",
        # terminal common
        "term_prompt_hint": "Type  help  and press Enter.",
        "term_unknown": "{c}: unknown command. Type 'help'.",
        "term_conn_fail": "(connection failed)",
        "cat_missing": "cat: {f}: no such file",
        # phase titles
        "backup_title": "FASE 1 — Reclaim BACKUP-01",
        "backup_lead": "ShinyHunters locked your backup server. Investigate with the console and take it back before the timer runs out.",
        "backup_deadline": "Backup lost in",
        "wallet_title": "FASE 2 — Recover Rick's wallet",
        "wallet_lead": "The attacker is draining Rick's Bitcoin. Hack into their channel and recover from the right seed — before it's empty.",
        "wallet_deadline": "Wallet drained in",
        "aanval_title": "FASE 3 — ShinyHunters strike back",
        "aanval_lead": "They're back and hitting the backup again. Stop the intrusion, then verify the backup.",
        "aanval_deadline": "They finish in",
        "lock_text": "BACKUP-01 reclaimed!",
        # betalen
        "pay_title": "Backup lost — pay to continue",
        "pay_lead": "You didn't reclaim BACKUP-01 in time. To keep going and still save Rick's wallet, the only option left is to pay {eur} EUR ({btc} BTC). (Simulation — no real payment.)",
        "pay_to": "Attacker wallet",
        "pay_btn": "Confirm Bitcoin payment",
        "pay_done": "Payment sent. Access restored — on to recovering the wallet (at a steep price).",
        # teruggeven
        "give_title": "Return the wallet to Rick",
        "give_lead": "Rick's Bitcoin is recovered and safe in a new wallet. Hand it back to him.",
        "give_btn": "🤝 Return the wallet to Rick",
        "give_done": "Rick has his wallet back. Now file the police report.",
        # aangifte (alleen flag)
        "rep_title": "File a police report",
        "rep_lead": "Final step: submit the reward flag you got when you recovered the wallet.",
        "f_flag": "Reward flag",
        "f_flag_ph": "flag{...}",
        "rep_submit": "Submit report",
        "rep_wrong": "That is not the flag you received. Check your notepad. {n} attempt(s) left.",
        "locked_title": "Report locked",
        "locked_text": "Too many wrong tries. This form is locked and the challenge is marked as failed. Ask the game master for another try.",
        # eindes
        "end_good_title": "✅ Incident handled — the good way",
        "end_good_body": "You reclaimed the backup in time, recovered Rick's wallet and reported it. ShinyHunters still torched the backup later, but you lost no money. Full marks.",
        "end_bad_title": "⚠ Incident handled — the expensive way",
        "end_bad_body": "You couldn't reclaim the backup in time and had to pay 5000 EUR. You did recover Rick's wallet and reported it — a hard, costly lesson. Half marks.",
        "flag_label": "Your flag:",
        "end_platform": "Enter this flag on the BreachOut platform.",
    },
    "nl": {
        "brand": "IronHold Labs — SOC",
        "nav_screen": "Het scherm", "nav_backup": "1. Backup", "nav_wallet": "2. Wallet",
        "nav_aanval": "3. Aanval", "nav_report": "Aangifte",
        "foot": "IronHold Labs — Security Operations. Simulatie; er wordt niets echt versleuteld.",
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "ransom_title": "AL UW BESTANDEN ZIJN VERSLEUTELD",
        "ransom_body": "Uw servers zijn vergrendeld door {fam}. Betaal {eur} EUR ({btc} BTC) binnen {hrs} uur, anders verliest u alles.",
        "ransom_addr": "Stuur Bitcoin naar:",
        "deadline": "Deadline",
        "chat_title": "Servicedesk",
        "chat_1": "{who} rent binnen, buiten adem:",
        "chat_rick1": "Alles is versleuteld! En mijn crypto-wallet was gekoppeld aan mijn werklaptop — mijn seed stond in een document. Ze hebben {amt} aan Bitcoin van me gestolen!",
        "chat_rick2": "Alsjeblieft — kun je het allemaal terughacken?!",
        "chat_you": "Jij (first responder):",
        "chat_opt_pay": "In paniek betalen",
        "chat_opt_calm": "Rustig blijven — open de response-console",
        "chat_badpay": "Eerst betalen is precies wat ze willen. Hou je hoofd koel — probeer eerst de backup terug te pakken.",
        "chat_go": "Kom op. BACKUP-01 is nog herstelbaar. Open de console en pak 'm terug voordat het te laat is.",
        "start_btn": "Open de response-console →",
        "term_prompt_hint": "Typ  help  en druk op Enter.",
        "term_unknown": "{c}: onbekend commando. Typ 'help'.",
        "term_conn_fail": "(verbinding mislukt)",
        "cat_missing": "cat: {f}: bestaat niet",
        "backup_title": "FASE 1 — Herover BACKUP-01",
        "backup_lead": "ShinyHunters hebben je back-upserver vergrendeld. Onderzoek met de console en pak 'm terug voordat de tijd om is.",
        "backup_deadline": "Backup kwijt over",
        "wallet_title": "FASE 2 — Herstel Rick's wallet",
        "wallet_lead": "De aanvaller trekt Rick's Bitcoin leeg. Hack hun kanaal binnen en herstel vanuit de juiste seed — voordat 'ie leeg is.",
        "wallet_deadline": "Wallet leeg over",
        "aanval_title": "FASE 3 — ShinyHunters slaan terug",
        "aanval_lead": "Ze zijn terug en vallen de back-up opnieuw aan. Stop de inbraak en controleer daarna de back-up.",
        "aanval_deadline": "Ze zijn klaar over",
        "lock_text": "BACKUP-01 heroverd!",
        "pay_title": "Backup kwijt — betaal om door te gaan",
        "pay_lead": "Je hebt BACKUP-01 niet op tijd heroverd. Om door te gaan en Rick's wallet alsnog te redden, is de enige optie {eur} EUR ({btc} BTC) betalen. (Simulatie — geen echte betaling.)",
        "pay_to": "Wallet aanvaller",
        "pay_btn": "Bevestig Bitcoin-betaling",
        "pay_done": "Betaling verstuurd. Toegang hersteld — door naar het herstellen van de wallet (tegen een hoge prijs).",
        "give_title": "Geef de wallet terug aan Rick",
        "give_lead": "Rick's Bitcoin is hersteld en veilig in een nieuwe wallet. Geef 'm aan hem terug.",
        "give_btn": "🤝 Geef de wallet terug aan Rick",
        "give_done": "Rick heeft zijn wallet terug. Doe nu de politie-aangifte.",
        "rep_title": "Doe aangifte bij de politie",
        "rep_lead": "Laatste stap: lever de belonings-flag in die je kreeg toen je de wallet herstelde.",
        "f_flag": "Belonings-flag",
        "f_flag_ph": "flag{...}",
        "rep_submit": "Aangifte versturen",
        "rep_wrong": "Dat is niet de flag die je kreeg. Check je kladblok. Nog {n} poging(en).",
        "locked_title": "Aangifte geblokkeerd",
        "locked_text": "Te veel foute pogingen. Dit formulier is op slot en de challenge is gefaald. Vraag de spelleider om een nieuwe poging.",
        "end_good_title": "✅ Incident afgehandeld — de goede manier",
        "end_good_body": "Je heroverde de back-up op tijd, herstelde Rick's wallet en deed aangifte. ShinyHunters verwoestten de back-up later alsnog, maar je verloor geen geld. Volledige punten.",
        "end_bad_title": "⚠ Incident afgehandeld — de dure manier",
        "end_bad_body": "Je kon de back-up niet op tijd heroveren en moest 5000 EUR betalen. Je herstelde Rick's wallet wél en deed aangifte — een dure les. Halve punten.",
        "flag_label": "Je flag:",
        "end_platform": "Vul deze flag in op het BreachOut-platform.",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)


def tr(obj, lang):
    if isinstance(obj, dict) and obj and set(obj) <= set(LANGS):
        return obj.get(lang) or obj.get("en") or ""
    return obj


DEFAULT = {"backup_start": None, "backup_done": False, "backup_fast": None,
           "paid": False, "wallet_start": None, "wallet_done": False,
           "w_connected": False, "aanval_start": None, "aanval_done": False,
           "a_killed": False, "a_blocked": False, "returned": False,
           "reported": False, "ending": None, "attempts": 0}


def read_state():
    try:
        st = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return {**DEFAULT, **st}
    except (FileNotFoundError, ValueError):
        return dict(DEFAULT)


def update_state(fn):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "voortgang.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        st = read_state()
        fn(st)
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(st), encoding="utf-8")
        tmp.replace(STATE_FILE)
        return st


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.route("/api/concept", methods=["GET", "PUT"])
def api_concept():
    concept = read_json(CONCEPT_FILE, {"velden": {}, "versie": 0})
    if request.method == "PUT":
        nieuw = (request.get_json(silent=True) or {}).get("velden", {})
        for k in FORM_FIELDS:
            if k in nieuw:
                concept["velden"][k] = str(nieuw[k])[:80]
        concept["versie"] = time.time()
        write_json(CONCEPT_FILE, concept)
    return jsonify(concept)


def ctx(**extra):
    lang = get_lang()
    base = {"lang": lang, "t": UI[lang], "root": "", "data": load()}
    base.update(extra)
    return base


def reward_flag(st, data):
    return data["flag_goed"] if st["backup_fast"] else data["flag_duur"]


# ------------------------------------------------------------- scherm
@app.route("/")
def screen():
    return render_template("screen.html", actief="screen", **ctx())


# ------------------------------------------------------------- FASE 1: backup (2 min)
@app.route("/backup")
def backup():
    st = read_state()
    data = load()
    if st["backup_done"]:
        if st["backup_fast"] or st["paid"]:
            return redirect("wallet")
        return redirect("betalen")
    if st["backup_start"] is None:
        st = update_state(lambda s: s.update(backup_start=time.time()))
    remaining = max(0, int(data["backup_sec"] - (time.time() - st["backup_start"])))
    return render_template("terminal.html", actief="backup", fase="backup",
                           endpoint="api/backup", on_timeout="pay",
                           title=UI[get_lang()]["backup_title"], lead=UI[get_lang()]["backup_lead"],
                           deadline_lbl=UI[get_lang()]["backup_deadline"],
                           remaining=remaining, limit=data["backup_sec"], **ctx())


@app.route("/api/backup", methods=["POST"])
def api_backup():
    st = read_state()
    data = load()
    lang = get_lang()
    t = UI[lang]
    tx = data["teksten"]
    if st["backup_done"]:
        return jsonify(done=True, next="wallet" if (st["backup_fast"] or st["paid"]) else "betalen")
    raw = ((request.get_json(silent=True) or {}).get("cmd") or "").strip()
    if not raw:
        return jsonify(out="")
    parts = raw.split()
    word = parts[0].lower()
    args = parts[1:]
    if word == "help":
        return jsonify(out=tr(tx["b_help"], lang))
    if word == "clear":
        return jsonify(clear=True)
    if word == "status":
        return jsonify(out=tr(tx["b_status"], lang))
    if word == "logs":
        return jsonify(out=tr(tx["b_logs"], lang))
    if word == "ls":
        return jsonify(out=tr(tx["b_ls"], lang))
    if word in ("cat", "more", "less"):
        if not args:
            return jsonify(out=t["cat_missing"].format(f=""))
        f = args[0].lower().lstrip("/").replace("tmp/", "")
        if f in ("sh_recovery.tmp", "recovery.tmp"):
            return jsonify(out=tr(tx["b_token_file"], lang))
        if f in ("server.log", "log"):
            return jsonify(out=tr(tx["b_logs"], lang))
        if f in ("notes.txt", "notes"):
            return jsonify(out=tr(tx["b_notes"], lang))
        return jsonify(out=t["cat_missing"].format(f=args[0]))
    if word == "reclaim":
        tnorm = "".join(args).lower()
        token = data["antwoord"]["backup_token"].lower()
        if "backup" in tnorm and token.replace("-", "") in tnorm.replace("-", ""):
            elapsed = time.time() - (st["backup_start"] or 0)
            if elapsed <= data["backup_sec"]:
                update_state(lambda s: s.update(backup_done=True, backup_fast=True))
                return jsonify(lock=True, next="wallet")
            update_state(lambda s: s.update(backup_done=True, backup_fast=False))
            return jsonify(out=tr(tx["b_reclaim_late"], lang), done=True, next="betalen")
        return jsonify(out=tr(tx["b_reclaim_bad"], lang))
    return jsonify(out=t["term_unknown"].format(c=word))


# ------------------------------------------------------------- Betalen (trage pad)
@app.route("/betalen")
def betalen():
    st = read_state()
    if not st["backup_done"]:
        st = update_state(lambda s: s.update(backup_done=True, backup_fast=False))
    if st["backup_fast"] or st["paid"]:
        return redirect("wallet")
    return render_template("betalen.html", actief="backup", **ctx())


@app.route("/api/betalen", methods=["POST"])
def api_betalen():
    st = read_state()
    if st["backup_fast"]:
        return jsonify(ok=False), 400
    update_state(lambda s: s.update(backup_done=True, paid=True))
    return jsonify(ok=True)


def wallet_ready(st):
    return st["backup_done"] and (st["backup_fast"] or st["paid"])


# ------------------------------------------------------------- FASE 2: wallet (5 min)
@app.route("/wallet")
def wallet():
    st = read_state()
    data = load()
    if not wallet_ready(st):
        return redirect("betalen" if st["backup_done"] else "backup")
    if st["wallet_done"]:
        return redirect("aanval")
    if st["wallet_start"] is None:
        st = update_state(lambda s: s.update(wallet_start=time.time()))
    remaining = max(0, int(data["wallet_sec"] - (time.time() - st["wallet_start"])))
    return render_template("terminal.html", actief="wallet", fase="wallet",
                           endpoint="api/wallet", on_timeout="fail",
                           title=UI[get_lang()]["wallet_title"], lead=UI[get_lang()]["wallet_lead"],
                           deadline_lbl=UI[get_lang()]["wallet_deadline"],
                           remaining=remaining, limit=data["wallet_sec"], **ctx())


@app.route("/api/wallet", methods=["POST"])
def api_wallet():
    st = read_state()
    data = load()
    lang = get_lang()
    t = UI[lang]
    tx = data["teksten"]
    if st["wallet_done"]:
        return jsonify(done=True, next="aanval")
    raw = ((request.get_json(silent=True) or {}).get("cmd") or "").strip()
    if not raw:
        return jsonify(out="")
    parts = raw.split()
    word = parts[0].lower()
    args = parts[1:]
    if word == "help":
        return jsonify(out=tr(tx["w_help"], lang))
    if word == "clear":
        return jsonify(clear=True)
    if word == "scan":
        return jsonify(out=tr(tx["w_scan"], lang))
    if word in ("trace", "traceroute"):
        return jsonify(out=tr(tx["w_trace"], lang))
    if word == "vault":
        lines = []
        for k in data.get("wallet_kluis", []):
            lines.append("  {:<10} {}".format(k["id"], tr({"en": k["en"], "nl": k["nl"]}, lang)))
        return jsonify(out="\n".join(lines))
    if word == "connect":
        if len(args) >= 2 and args[0] == data["antwoord"]["c2_ip"] and args[1] == str(data["antwoord"]["c2_port"]):
            update_state(lambda s: s.update(w_connected=True))
            return jsonify(out=tr(tx["w_connect_ok"], lang))
        return jsonify(out=tr(tx["w_connect_bad"], lang))
    if word == "recover":
        if not st["w_connected"]:
            return jsonify(out=tr(tx["w_recover_need_conn"], lang))
        seed = (args[0].upper() if args else "")
        ids = {k["id"].upper(): k for k in data.get("wallet_kluis", [])}
        if seed == data["antwoord"]["wallet_seed"].upper():
            update_state(lambda s: s.update(wallet_done=True))
            flag = reward_flag(read_state(), data)
            return jsonify(out=tr(tx["w_recover_ok"], lang).format(flag=flag), done=True, next="aanval")
        if seed in ids:
            meta = (str(ids[seed]["en"]) + str(ids[seed]["nl"])).lower()
            if any(w in meta for w in ("leak", "gelek")):
                return jsonify(out=tr(tx["w_recover_leaked"], lang))
            return jsonify(out=tr(tx["w_recover_empty"], lang))
        return jsonify(out=tr(tx["w_recover_bad"], lang))
    return jsonify(out=t["term_unknown"].format(c=word))


# ------------------------------------------------------------- FASE 3: aanval (2 min)
@app.route("/aanval")
def aanval():
    st = read_state()
    data = load()
    if not st["wallet_done"]:
        return redirect("wallet")
    if st["aanval_done"]:
        return redirect("teruggeven")
    if st["aanval_start"] is None:
        st = update_state(lambda s: s.update(aanval_start=time.time()))
    remaining = max(0, int(data["aanval_sec"] - (time.time() - st["aanval_start"])))
    return render_template("terminal.html", actief="aanval", fase="aanval",
                           endpoint="api/aanval", on_timeout="fail",
                           title=UI[get_lang()]["aanval_title"], lead=UI[get_lang()]["aanval_lead"],
                           deadline_lbl=UI[get_lang()]["aanval_deadline"],
                           remaining=remaining, limit=data["aanval_sec"], **ctx())


@app.route("/api/aanval", methods=["POST"])
def api_aanval():
    st = read_state()
    data = load()
    lang = get_lang()
    t = UI[lang]
    tx = data["teksten"]
    if st["aanval_done"]:
        return jsonify(done=True, next="teruggeven")
    raw = ((request.get_json(silent=True) or {}).get("cmd") or "").strip()
    if not raw:
        return jsonify(out="")
    parts = raw.split()
    word = parts[0].lower()
    args = parts[1:]
    if word == "help":
        return jsonify(out=tr(tx["a_help"], lang))
    if word == "clear":
        return jsonify(clear=True)
    if word in ("scan", "status"):
        return jsonify(out=tr(tx["a_scan"], lang))
    if word == "kill":
        if args and "shadowlock" in args[0].lower():
            update_state(lambda s: s.update(a_killed=True))
            return jsonify(out=tr(tx["a_kill_ok"], lang))
        return jsonify(out="kill: no such process")
    if word == "block":
        if args and args[0] == data["antwoord"]["c2_ip"]:
            update_state(lambda s: s.update(a_blocked=True))
            return jsonify(out=tr(tx["a_block_ok"], lang))
        return jsonify(out="block: unknown ip")
    if word in ("verify-backup", "verify", "verify_backup"):
        st = read_state()
        if st["a_killed"] and st["a_blocked"]:
            update_state(lambda s: s.update(aanval_done=True))
            return jsonify(out=tr(tx["a_verify_ok"], lang), done=True, next="teruggeven")
        return jsonify(out=tr(tx["a_verify_need"], lang))
    return jsonify(out=t["term_unknown"].format(c=word))


# ------------------------------------------------------------- Wallet teruggeven
@app.route("/teruggeven")
def teruggeven():
    st = read_state()
    if not st["aanval_done"]:
        return redirect("aanval")
    if st["returned"]:
        return redirect("aangifte")
    return render_template("teruggeven.html", actief="report", **ctx())


@app.route("/api/teruggeven", methods=["POST"])
def api_teruggeven():
    st = read_state()
    if not st["aanval_done"]:
        return jsonify(ok=False), 400
    update_state(lambda s: s.update(returned=True))
    return jsonify(ok=True)


# ------------------------------------------------------------- Aangifte (flag inleveren)
@app.route("/aangifte")
def aangifte():
    st = read_state()
    data = load()
    if not st["returned"]:
        return redirect("teruggeven")
    if st["reported"]:
        return redirect("einde")
    if st["attempts"] >= data["max_pogingen"]:
        return render_template("aangifte.html", actief="report", status="slot", **ctx())
    return render_template("aangifte.html", actief="report", status="leeg", **ctx())


@app.route("/api/aangifte", methods=["POST"])
def api_aangifte():
    st = read_state()
    data = load()
    if not st["returned"]:
        return jsonify(ok=False, error="volgorde"), 400
    if st["reported"]:
        return jsonify(ok=True, ending=st["ending"])
    if st["attempts"] >= data["max_pogingen"]:
        return jsonify(ok=False, locked=True)
    ingevuld = ((request.get_json(silent=True) or {}).get("flag") or "").strip()
    verwacht = reward_flag(st, data)
    if ingevuld == verwacht:
        ending = "goed" if st["backup_fast"] else "duur"
        update_state(lambda s: s.update(reported=True, ending=ending))
        return jsonify(ok=True, ending=ending)
    st = update_state(lambda s: s.update(attempts=s["attempts"] + 1))
    over = data["max_pogingen"] - st["attempts"]
    if over <= 0:
        return jsonify(ok=False, locked=True)
    return jsonify(ok=False, over=over)


@app.route("/einde")
def einde():
    st = read_state()
    data = load()
    if not st["reported"] or st["ending"] is None:
        return redirect("aangifte")
    flag = data["flag_goed"] if st["ending"] == "goed" else data["flag_duur"]
    return render_template("einde.html", actief="report", ending=st["ending"], flag=flag, **ctx())


@app.route("/api/flag")
def api_flag():
    try:
        d = load()
        return jsonify(flag=d["flag_goed"], half_flag=d["flag_duur"])
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
