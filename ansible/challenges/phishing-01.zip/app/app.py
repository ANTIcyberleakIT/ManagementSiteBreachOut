"""
BreachOut escaperoom: De verdachte mailbox (phishing-01)

Kleine Flask-app die een nep-mailbox toont. De deelnemer moet de phishingmail
herkennen en melden. Alleen bij de juiste mail verschijnt de unieke flag van
het team. De flag staat in een bestand dat Ansible bij het starten neerzet en
wordt nooit naar de browser gestuurd tenzij de juiste mail gemeld is.

Alle links zijn relatief, zodat de app werkt achter de webserver-proxy op
/room/<token>/.

Taal: Engels (standaard) of Nederlands. De room volgt de taalkeuze van het
BreachOut-platform via het cookie room_lang. Inhoud en regels zijn identiek.
"""
import json
from pathlib import Path

import time
import fcntl
from flask import Flask, abort, jsonify, render_template, request

BASE = Path("/opt/mailbox")
STATE_DIR = BASE / "state"
NOTES_FILE = STATE_DIR / "kladblok.json"
NOTES_MAX = 20000
EMAILS_FILE = BASE / "emails.json"
FLAG_FILE = BASE / "flag.txt"

app = Flask(__name__)

LANGS = ("en", "nl")

UI = {
    "en": {
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
        "inbox": "Inbox", "from": "From", "to": "To", "date": "Date", "back": "Back",
        "report": "Report as phishing",
        "good_title": "Well spotted!",
        "good_text": "This e-mail did not come from your colleague, but from a free Gmail address with her name. Enter this code on the BreachOut platform:",
        "bad_title": "This is a genuine e-mail",
        "bad_text": "The e-mail from {naam} simply comes from the company domain {domein}. Take another good look at the other e-mails.",
        "back_inbox": "Back to inbox",
    },
    "nl": {
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
        "inbox": "Postvak IN", "from": "Van", "to": "Aan", "date": "Datum", "back": "Terug",
        "report": "Meld als phishing",
        "good_title": "Goed gezien!",
        "good_text": "Deze mail kwam niet van je collega, maar van een gratis Gmail-adres met haar naam. Vul deze code in op het BreachOut-platform:",
        "bad_title": "Dit is een echte mail",
        "bad_text": "De mail van {naam} komt gewoon van het bedrijfsdomein {domein}. Kijk nog eens goed naar de andere mails.",
        "back_inbox": "Terug naar Postvak IN",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def tr(obj, lang):
    """Vertaalbare teksten ({en: .., nl: ..}) omzetten naar de gekozen taal."""
    if isinstance(obj, dict):
        if obj and set(obj) <= set(LANGS):
            return obj.get(lang) or obj.get("en") or obj.get("nl") or ""
        return {k: tr(v, lang) for k, v in obj.items()}
    if isinstance(obj, list):
        return [tr(v, lang) for v in obj]
    return obj



def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    """Gedeeld kladblok voor het team (server-side, zodat teamgenoten het ook zien)."""
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.context_processor
def common():
    lang = get_lang()
    return {"lang": lang, "t": UI[lang]}


def load_mailbox():
    with EMAILS_FILE.open(encoding="utf-8") as f:
        return tr(json.load(f), get_lang())


def get_mail(mail_id):
    data = load_mailbox()
    for mail in data["emails"]:
        if mail["id"] == mail_id:
            return data, mail
    abort(404)


@app.route("/")
def inbox():
    data = load_mailbox()
    return render_template("inbox.html", data=data)


@app.route("/mail/<int:mail_id>")
def mail(mail_id):
    data, m = get_mail(mail_id)
    return render_template("mail.html", data=data, mail=m)


@app.route("/melden/<int:mail_id>", methods=["POST"])
def melden(mail_id):
    data, m = get_mail(mail_id)
    if m["phishing"]:
        flag = FLAG_FILE.read_text(encoding="utf-8").strip()
        return render_template("resultaat.html", data=data, goed=True, flag=flag)
    return render_template("resultaat.html", data=data, goed=False, mail=m)


@app.route("/api/flag")
def api_flag():
    """Door het BreachOut-platform opgehaald (spelleider) om de unieke flag van
    deze draaiende room te tonen. Alleen de webserver kan dit IP bereiken."""
    try:
        return jsonify(flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
