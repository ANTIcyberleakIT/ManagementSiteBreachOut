"""
BreachOut escaperoom: The Number in the URL (idor-factuur-01)

Intermediate web-challenge over IDOR (Insecure Direct Object Reference).
De speler logt in op een nep-klantenportaal en ziet zijn eigen factuur op
/factuur?id=1042. Het portaal controleert NIET of de factuur van de ingelogde
gebruiker is, dus door het id te verlagen naar 1041 ziet de speler de factuur
van een andere klant - met daarin de unieke flag.

Leerdoel: ingelogd zijn betekent niet dat je overal bij mag.

Geen database: vijf facturen staan hardcoded in data.json.
Taal: Engels (standaard) of Nederlands, volgt het platform via cookie room_lang.
Alle links zijn relatief, zodat de app werkt achter de webserver-proxy.
"""
import json
from pathlib import Path

import time
import fcntl
from flask import (Flask, jsonify, redirect, render_template, request,
                   session, url_for)

BASE = Path("/opt/portal")
STATE_DIR = BASE / "state"
NOTES_FILE = STATE_DIR / "kladblok.json"
NOTES_MAX = 20000
DATA_FILE = BASE / "data.json"
FLAG_FILE = BASE / "flag.txt"

app = Flask(__name__)
# Vaste sleutel zodat de sessie-cookie geldig blijft over beide gunicorn-workers.
# Niet beveiligingsgevoelig: de sessie markeert alleen 'ingelogd'.
app.secret_key = "breachout-portal-idor-factuur-01"

LANGS = ("en", "nl")

UI = {
    "en": {
        "portal": "Customer portal",
        "login_title": "Sign in to the customer portal",
        "login_sub": "Use the demo account below to view your invoices.",
        "demo_note": "Demo account",
        "u": "Username", "p": "Password", "login": "Sign in", "logout": "Sign out",
        "wrong": "Wrong username or password.",
        "hi": "Signed in as", "my_invoice": "My invoice",
        "inv_title": "Invoice", "inv_customer": "Customer", "inv_date": "Date",
        "inv_ref": "Payment reference", "inv_desc": "Description", "inv_amount": "Amount",
        "inv_total": "Total", "eur": "EUR",
        "nf_title": "Invoice not found",
        "nf_text": "There is no invoice with that number.",
        "foot": "IronHold Labs BV - customer portal. For questions: billing@ironholdlabs.nl",
        "notes": "Notepad", "notes_shared": "shared", "notes_ph": "Write down your findings here. Your teammates see this too.",
        "notes_typing": "typing...", "notes_saving": "saving...", "notes_saved": "saved", "notes_failed": "not saved!",
    },
    "nl": {
        "portal": "Klantportaal",
        "login_title": "Inloggen op het klantportaal",
        "login_sub": "Gebruik het demo-account hieronder om je facturen te bekijken.",
        "demo_note": "Demo-account",
        "u": "Gebruikersnaam", "p": "Wachtwoord", "login": "Inloggen", "logout": "Uitloggen",
        "wrong": "Verkeerde gebruikersnaam of wachtwoord.",
        "hi": "Ingelogd als", "my_invoice": "Mijn factuur",
        "inv_title": "Factuur", "inv_customer": "Klant", "inv_date": "Datum",
        "inv_ref": "Betalingskenmerk", "inv_desc": "Omschrijving", "inv_amount": "Bedrag",
        "inv_total": "Totaal", "eur": "EUR",
        "nf_title": "Factuur niet gevonden",
        "nf_text": "Er is geen factuur met dat nummer.",
        "foot": "IronHold Labs BV - klantportaal. Vragen: facturen@ironholdlabs.nl",
        "notes": "Kladblok", "notes_shared": "gedeeld", "notes_ph": "Schrijf hier je bevindingen op. Je teamgenoten zien dit ook.",
        "notes_typing": "typen...", "notes_saving": "opslaan...", "notes_saved": "opgeslagen", "notes_failed": "niet opgeslagen!",
    },
}


def get_lang():
    lang = request.args.get("lang") or request.cookies.get("room_lang")
    return lang if lang in LANGS else "en"


def load():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)


def facturen_dict(data):
    return {int(f["id"]): f for f in data["facturen"]}



def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return default


def write_json(path, data):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "opslag.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)


@app.route("/api/kladblok", methods=["GET", "PUT"])
def api_kladblok():
    """Gedeeld kladblok voor het team (server-side, zodat teamgenoten het ook zien)."""
    if request.method == "PUT":
        tekst = str((request.get_json(silent=True) or {}).get("tekst", ""))[:NOTES_MAX]
        write_json(NOTES_FILE, {"tekst": tekst, "versie": time.time()})
    return jsonify(read_json(NOTES_FILE, {"tekst": "", "versie": 0}))


@app.context_processor
def common():
    lang = get_lang()
    data = load()
    return {"lang": lang, "t": UI[lang], "bedrijf": data["bedrijf"],
            "ingelogd": bool(session.get("in")), "eigen": session.get("klant")}


@app.route("/")
def home():
    if session.get("in"):
        return redirect(f"factuur?id={session.get('klant')}")
    return redirect("login")


@app.route("/login", methods=["GET", "POST"])
def login():
    data = load()
    demo = data["demo"]
    if request.method == "POST":
        u = (request.form.get("user") or "").strip()
        p = request.form.get("pass") or ""
        if u == demo["gebruiker"] and p == demo["wachtwoord"]:
            session["in"] = True
            session["klant"] = int(demo["eigen_factuur"])
            return redirect(f"factuur?id={demo['eigen_factuur']}")
        return render_template("login.html", fout=True,
                               demo_user=demo["gebruiker"], demo_pass=demo["wachtwoord"])
    return render_template("login.html", fout=False,
                           demo_user=demo["gebruiker"], demo_pass=demo["wachtwoord"])


@app.route("/logout")
def logout():
    session.clear()
    return redirect("login")


@app.route("/factuur")
def factuur():
    # Je moet ingelogd zijn ...
    if not session.get("in"):
        return redirect("login")
    data = load()
    facturen = facturen_dict(data)
    try:
        fid = int(request.args.get("id", ""))
    except (TypeError, ValueError):
        fid = session.get("klant")

    fac = facturen.get(fid)
    if not fac:
        return render_template("notfound.html"), 404

    # ... maar er is GEEN eigenaarscheck (de IDOR). Elke ingelogde gebruiker
    # kan elk factuur-id opvragen. Op de flag-factuur staat de echte flag.
    flag = None
    if fid == int(data["flag_factuur"]):
        try:
            flag = FLAG_FILE.read_text(encoding="utf-8").strip()
        except Exception:
            flag = None
    return render_template("factuur.html", fac=fac, flag=flag, fid=fid)


@app.route("/api/flag")
def api_flag():
    """Door het BreachOut-platform opgehaald (spelleider) om de unieke flag van
    deze draaiende room te kunnen tonen."""
    try:
        return jsonify(flag=FLAG_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return jsonify(flag=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
